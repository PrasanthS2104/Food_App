'use client'

import { Card, CardContent } from '@/components/ui/card'
import { 
  Users, 
  Calendar, 
  Clock, 
  Bed, 
  UserCheck, 
  AlertTriangle,
  CheckCircle,
  FileText
} from 'lucide-react'
import { dashboardStats } from '@/lib/mock-data'

const stats = [
  {
    name: 'Total Patients',
    value: dashboardStats.totalPatients.toLocaleString(),
    change: '+12%',
    changeType: 'positive',
    icon: Users,
    color: 'bg-primary/10 text-primary'
  },
  {
    name: 'Today\'s Appointments',
    value: dashboardStats.todayAppointments.toString(),
    change: '+8%',
    changeType: 'positive',
    icon: Calendar,
    color: 'bg-accent/10 text-accent'
  },
  {
    name: 'Avg. Wait Time',
    value: `${dashboardStats.averageWaitTime} min`,
    change: '-15%',
    changeType: 'positive',
    icon: Clock,
    color: 'bg-success/10 text-success'
  },
  {
    name: 'Bed Occupancy',
    value: `${dashboardStats.bedOccupancy}%`,
    change: '+3%',
    changeType: 'neutral',
    icon: Bed,
    color: 'bg-warning/10 text-warning'
  },
  {
    name: 'Staff On Duty',
    value: dashboardStats.staffOnDuty.toString(),
    change: 'Full',
    changeType: 'positive',
    icon: UserCheck,
    color: 'bg-primary/10 text-primary'
  },
  {
    name: 'Emergency Cases',
    value: dashboardStats.emergencyCases.toString(),
    change: 'Active',
    changeType: 'warning',
    icon: AlertTriangle,
    color: 'bg-destructive/10 text-destructive'
  },
  {
    name: 'Completed Today',
    value: dashboardStats.completedConsultations.toString(),
    change: '+22%',
    changeType: 'positive',
    icon: CheckCircle,
    color: 'bg-success/10 text-success'
  },
  {
    name: 'Pending Reports',
    value: dashboardStats.pendingLabReports.toString(),
    change: '-5%',
    changeType: 'positive',
    icon: FileText,
    color: 'bg-accent/10 text-accent'
  },
]

export function StatsCards() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <Card key={stat.name} className="relative overflow-hidden border-0 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">{stat.name}</p>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <div className={`inline-flex items-center text-xs font-medium px-2 py-0.5 rounded-full ${
                  stat.changeType === 'positive' ? 'bg-success/10 text-success' :
                  stat.changeType === 'warning' ? 'bg-warning/10 text-warning' :
                  'bg-muted text-muted-foreground'
                }`}>
                  {stat.change}
                </div>
              </div>
              <div className={`p-3 rounded-xl ${stat.color}`}>
                <stat.icon className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-primary/20 via-primary/40 to-primary/20" />
        </Card>
      ))}
    </div>
  )
}
