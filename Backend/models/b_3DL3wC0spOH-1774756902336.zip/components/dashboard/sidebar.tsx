'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  Stethoscope, 
  Building2, 
  Activity,
  BarChart3,
  Settings,
  QrCode,
  Heart,
  Bell,
  Menu,
  X,
  ChevronRight,
  Brain
} from 'lucide-react'

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Patient Portal', href: '/dashboard/patients', icon: Users },
  { name: 'Smart Card', href: '/dashboard/smart-card', icon: QrCode },
  { name: 'Appointments', href: '/dashboard/appointments', icon: Calendar },
  { name: 'Clinician View', href: '/dashboard/clinician', icon: Stethoscope },
  { name: 'Departments', href: '/dashboard/departments', icon: Building2 },
  { name: 'Vital Signs', href: '/dashboard/vitals', icon: Heart },
  { name: 'Queue Management', href: '/dashboard/queue', icon: Activity },
  { name: 'Resource Monitor', href: '/dashboard/resources', icon: BarChart3 },
  { name: 'AI Predictions', href: '/dashboard/ai-insights', icon: Brain },
]

export function Sidebar() {
  const pathname = usePathname()
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isMobileOpen, setIsMobileOpen] = useState(false)

  return (
    <>
      {/* Mobile menu button */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 lg:hidden"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
      >
        {isMobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </Button>

      {/* Mobile overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 z-40 h-screen bg-sidebar text-sidebar-foreground transition-all duration-300',
          isCollapsed ? 'w-20' : 'w-72',
          isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className={cn(
            'flex items-center gap-3 px-6 py-6 border-b border-sidebar-border',
            isCollapsed && 'justify-center px-4'
          )}>
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-sidebar-primary">
              <Activity className="h-6 w-6 text-sidebar-primary-foreground" />
            </div>
            {!isCollapsed && (
              <div>
                <h1 className="text-lg font-bold text-sidebar-foreground">MedFlow Pro</h1>
                <p className="text-xs text-sidebar-foreground/60">Healthcare System</p>
              </div>
            )}
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 px-3 py-4">
            <nav className="space-y-1">
              {navigation.map((item) => {
                const isActive = pathname === item.href || pathname.startsWith(item.href + '/')
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={() => setIsMobileOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group',
                      isActive 
                        ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-lg' 
                        : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
                      isCollapsed && 'justify-center px-3'
                    )}
                  >
                    <item.icon className={cn('h-5 w-5 flex-shrink-0', isActive && 'text-sidebar-primary-foreground')} />
                    {!isCollapsed && (
                      <>
                        <span className="flex-1 font-medium">{item.name}</span>
                        {isActive && <ChevronRight className="h-4 w-4" />}
                      </>
                    )}
                  </Link>
                )
              })}
            </nav>
          </ScrollArea>

          {/* Bottom section */}
          <div className="p-4 border-t border-sidebar-border">
            <Link
              href="/dashboard/settings"
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
                isCollapsed && 'justify-center px-3'
              )}
            >
              <Settings className="h-5 w-5" />
              {!isCollapsed && <span className="font-medium">Settings</span>}
            </Link>

            {/* Collapse button - desktop only */}
            <Button
              variant="ghost"
              size="sm"
              className="hidden lg:flex w-full mt-2 justify-center text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent"
              onClick={() => setIsCollapsed(!isCollapsed)}
            >
              <ChevronRight className={cn('h-4 w-4 transition-transform', isCollapsed ? '' : 'rotate-180')} />
              {!isCollapsed && <span className="ml-2">Collapse</span>}
            </Button>
          </div>
        </div>
      </aside>
    </>
  )
}
