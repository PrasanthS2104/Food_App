'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Button } from '@/components/ui/button'
import { Building2, Users, Clock, Bed, ChevronRight } from 'lucide-react'
import { mockDepartments } from '@/lib/mock-data'
import Link from 'next/link'

export function DepartmentOverview() {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-accent/10">
              <Building2 className="h-4 w-4 text-accent" />
            </div>
            <CardTitle className="text-lg">Department Status</CardTitle>
          </div>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/dashboard/departments" className="text-primary">
              View All <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-4">
          {mockDepartments.slice(0, 5).map((dept) => {
            const occupancyPercent = Math.round((dept.occupiedBeds / dept.totalBeds) * 100)
            const occupancyColor = occupancyPercent >= 90 ? 'bg-destructive' : 
                                   occupancyPercent >= 70 ? 'bg-warning' : 'bg-success'
            
            return (
              <div key={dept.id} className="p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-semibold text-sm">{dept.name}</h4>
                    <p className="text-xs text-muted-foreground">{dept.head}</p>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    dept.waitingPatients > 10 ? 'bg-destructive/10 text-destructive' :
                    dept.waitingPatients > 5 ? 'bg-warning/10 text-warning' :
                    'bg-success/10 text-success'
                  }`}>
                    {dept.waitingPatients} waiting
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1 text-muted-foreground">
                      <Bed className="h-3 w-3" />
                      Bed Occupancy
                    </span>
                    <span className="font-medium">{dept.occupiedBeds}/{dept.totalBeds}</span>
                  </div>
                  <Progress value={occupancyPercent} className={`h-2 ${occupancyColor}`} />
                </div>

                <div className="flex items-center gap-4 mt-3 pt-3 border-t border-border/50">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Users className="h-3 w-3" />
                    <span>{dept.doctors} Doctors</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>~{dept.averageWaitTime} min wait</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
