'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Activity, 
  UserPlus, 
  Stethoscope, 
  FileText, 
  AlertCircle,
  CheckCircle,
  Clock,
  Pill
} from 'lucide-react'

const activities = [
  {
    id: 1,
    type: 'check-in',
    icon: UserPlus,
    message: 'Rajesh Kumar checked in at Cardiology',
    time: '2 min ago',
    color: 'bg-primary/10 text-primary'
  },
  {
    id: 2,
    type: 'consultation',
    icon: Stethoscope,
    message: 'Dr. Priya Sharma started consultation with P-1245',
    time: '5 min ago',
    color: 'bg-accent/10 text-accent'
  },
  {
    id: 3,
    type: 'lab-result',
    icon: FileText,
    message: 'Lab results ready for Mohammed Ahmed',
    time: '12 min ago',
    color: 'bg-success/10 text-success'
  },
  {
    id: 4,
    type: 'emergency',
    icon: AlertCircle,
    message: 'Emergency admission in Room 105',
    time: '18 min ago',
    color: 'bg-destructive/10 text-destructive'
  },
  {
    id: 5,
    type: 'completed',
    icon: CheckCircle,
    message: 'Anjali Patel consultation completed',
    time: '25 min ago',
    color: 'bg-success/10 text-success'
  },
  {
    id: 6,
    type: 'prescription',
    icon: Pill,
    message: 'Prescription issued for P-1238',
    time: '32 min ago',
    color: 'bg-warning/10 text-warning'
  },
  {
    id: 7,
    type: 'appointment',
    icon: Clock,
    message: 'New appointment booked - Neurology',
    time: '45 min ago',
    color: 'bg-primary/10 text-primary'
  },
  {
    id: 8,
    type: 'check-in',
    icon: UserPlus,
    message: 'Vikram Singh checked in at General Medicine',
    time: '52 min ago',
    color: 'bg-primary/10 text-primary'
  },
]

export function RecentActivity() {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-success/10">
            <Activity className="h-4 w-4 text-success" />
          </div>
          <CardTitle className="text-lg">Recent Activity</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <ScrollArea className="h-[360px] pr-4">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-[19px] top-0 bottom-0 w-px bg-border" />
            
            <div className="space-y-4">
              {activities.map((activity) => (
                <div key={activity.id} className="relative flex items-start gap-4 pl-2">
                  <div className={`relative z-10 p-2 rounded-lg ${activity.color}`}>
                    <activity.icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 pt-1">
                    <p className="text-sm text-foreground leading-relaxed">{activity.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
