'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Button } from '@/components/ui/button'
import { Clock, AlertCircle, ChevronRight, Activity } from 'lucide-react'
import { mockQueue } from '@/lib/mock-data'
import Link from 'next/link'

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'emergency': return 'bg-destructive text-destructive-foreground'
    case 'urgent': return 'bg-warning text-warning-foreground'
    default: return 'bg-secondary text-secondary-foreground'
  }
}

const getStatusColor = (status: string) => {
  switch (status) {
    case 'in-progress': return 'bg-success/10 text-success border-success/30'
    case 'waiting': return 'bg-warning/10 text-warning border-warning/30'
    default: return 'bg-muted text-muted-foreground border-muted'
  }
}

const getStressColor = (score: number) => {
  if (score >= 7) return 'text-destructive'
  if (score >= 4) return 'text-warning'
  return 'text-success'
}

export function QueueWidget() {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-primary/10">
              <Activity className="h-4 w-4 text-primary" />
            </div>
            <CardTitle className="text-lg">Live Patient Queue</CardTitle>
          </div>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/dashboard/queue" className="text-primary">
              View All <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <ScrollArea className="h-[360px] pr-4">
          <div className="space-y-3">
            {mockQueue.slice(0, 6).map((entry, index) => (
              <div
                key={entry.id}
                className="flex items-center gap-4 p-3 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-semibold text-sm">
                  {entry.position}
                </div>
                
                <Avatar className="h-10 w-10 border-2 border-background">
                  <AvatarFallback className="bg-secondary text-secondary-foreground text-sm">
                    {entry.patientName.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm truncate">{entry.patientName}</p>
                    <Badge className={`text-[10px] px-1.5 py-0 ${getPriorityColor(entry.priority)}`}>
                      {entry.priority}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{entry.department}</p>
                </div>

                <div className="text-right space-y-1">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {entry.estimatedTime}
                  </div>
                  <Badge variant="outline" className={`text-[10px] ${getStatusColor(entry.status)}`}>
                    {entry.status}
                  </Badge>
                </div>

                {entry.stressIndex !== undefined && entry.stressIndex >= 5 && (
                  <div className={`flex items-center gap-1 ${getStressColor(entry.stressIndex)}`}>
                    <AlertCircle className="h-4 w-4" />
                    <span className="text-xs font-medium">{entry.stressIndex}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
