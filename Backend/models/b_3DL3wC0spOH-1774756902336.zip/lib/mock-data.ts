import { 
  Patient, 
  Doctor, 
  Department, 
  Appointment, 
  QueueEntry, 
  Resource,
  AIprediction,
  EmotionalStressIndex 
} from './types'

export const mockPatients: Patient[] = [
  {
    id: 'P001',
    name: 'Rajesh Kumar',
    age: 45,
    gender: 'male',
    phone: '+91 98765 43210',
    email: 'rajesh.kumar@email.com',
    bloodType: 'O+',
    allergies: ['Penicillin', 'Sulfa drugs'],
    medicalHistory: [
      {
        id: 'MR001',
        date: '2024-01-15',
        department: 'Cardiology',
        doctor: 'Dr. Priya Sharma',
        diagnosis: 'Hypertension Stage 1',
        prescription: [
          { medication: 'Amlodipine', dosage: '5mg', frequency: 'Once daily', duration: '30 days' },
          { medication: 'Aspirin', dosage: '75mg', frequency: 'Once daily', duration: '30 days' }
        ],
        notes: 'Patient advised to reduce salt intake and exercise regularly',
        vitals: {
          bloodPressure: { systolic: 145, diastolic: 92 },
          heartRate: 78,
          temperature: 98.4,
          oxygenSaturation: 98,
          respiratoryRate: 16,
          weight: 82,
          height: 175,
          recordedAt: '2024-01-15T10:30:00'
        }
      }
    ],
    emergencyContact: {
      name: 'Sunita Kumar',
      phone: '+91 98765 43211',
      relationship: 'Spouse'
    },
    insuranceId: 'INS-2024-001234',
    registrationDate: '2023-06-15'
  },
  {
    id: 'P002',
    name: 'Anjali Patel',
    age: 32,
    gender: 'female',
    phone: '+91 87654 32109',
    email: 'anjali.patel@email.com',
    bloodType: 'A+',
    allergies: [],
    medicalHistory: [],
    emergencyContact: {
      name: 'Vikram Patel',
      phone: '+91 87654 32110',
      relationship: 'Husband'
    },
    insuranceId: 'INS-2024-002345',
    registrationDate: '2024-02-20'
  },
  {
    id: 'P003',
    name: 'Mohammed Ahmed',
    age: 58,
    gender: 'male',
    phone: '+91 76543 21098',
    email: 'mohammed.ahmed@email.com',
    bloodType: 'B+',
    allergies: ['Aspirin'],
    medicalHistory: [],
    emergencyContact: {
      name: 'Fatima Ahmed',
      phone: '+91 76543 21099',
      relationship: 'Wife'
    },
    insuranceId: 'INS-2024-003456',
    registrationDate: '2023-11-10'
  }
]

export const mockDoctors: Doctor[] = [
  {
    id: 'D001',
    name: 'Dr. Priya Sharma',
    specialization: 'Cardiologist',
    department: 'Cardiology',
    qualification: 'MD, DM Cardiology',
    experience: 15,
    availableSlots: ['09:00', '10:00', '11:00', '14:00', '15:00'],
    currentPatients: 3,
    maxPatients: 20,
    status: 'available',
    rating: 4.8
  },
  {
    id: 'D002',
    name: 'Dr. Arun Verma',
    specialization: 'Orthopedic Surgeon',
    department: 'Orthopedics',
    qualification: 'MS Orthopedics',
    experience: 12,
    availableSlots: ['10:00', '11:00', '14:00', '16:00'],
    currentPatients: 5,
    maxPatients: 15,
    status: 'busy',
    rating: 4.6
  },
  {
    id: 'D003',
    name: 'Dr. Meera Reddy',
    specialization: 'Neurologist',
    department: 'Neurology',
    qualification: 'MD, DM Neurology',
    experience: 18,
    availableSlots: ['09:30', '10:30', '14:30', '15:30'],
    currentPatients: 2,
    maxPatients: 12,
    status: 'available',
    rating: 4.9
  },
  {
    id: 'D004',
    name: 'Dr. Sanjay Gupta',
    specialization: 'General Medicine',
    department: 'General Medicine',
    qualification: 'MD Internal Medicine',
    experience: 10,
    availableSlots: ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00'],
    currentPatients: 8,
    maxPatients: 30,
    status: 'busy',
    rating: 4.5
  },
  {
    id: 'D005',
    name: 'Dr. Kavitha Nair',
    specialization: 'Pediatrician',
    department: 'Pediatrics',
    qualification: 'MD Pediatrics',
    experience: 8,
    availableSlots: ['09:00', '10:00', '11:00', '14:00', '15:00'],
    currentPatients: 4,
    maxPatients: 25,
    status: 'available',
    rating: 4.7
  }
]

export const mockDepartments: Department[] = [
  {
    id: 'DEP001',
    name: 'Cardiology',
    head: 'Dr. Priya Sharma',
    totalBeds: 30,
    occupiedBeds: 22,
    waitingPatients: 8,
    averageWaitTime: 25,
    doctors: 6,
    nurses: 12,
    equipment: [
      { id: 'E001', name: 'ECG Machine', type: 'Diagnostic', status: 'available', location: 'Room 101', lastMaintenance: '2024-01-01', nextMaintenance: '2024-07-01' },
      { id: 'E002', name: 'Echocardiogram', type: 'Diagnostic', status: 'in-use', location: 'Room 102', lastMaintenance: '2024-02-15', nextMaintenance: '2024-08-15' }
    ]
  },
  {
    id: 'DEP002',
    name: 'Orthopedics',
    head: 'Dr. Arun Verma',
    totalBeds: 25,
    occupiedBeds: 18,
    waitingPatients: 5,
    averageWaitTime: 30,
    doctors: 5,
    nurses: 10,
    equipment: []
  },
  {
    id: 'DEP003',
    name: 'Neurology',
    head: 'Dr. Meera Reddy',
    totalBeds: 20,
    occupiedBeds: 15,
    waitingPatients: 3,
    averageWaitTime: 20,
    doctors: 4,
    nurses: 8,
    equipment: []
  },
  {
    id: 'DEP004',
    name: 'General Medicine',
    head: 'Dr. Sanjay Gupta',
    totalBeds: 50,
    occupiedBeds: 42,
    waitingPatients: 15,
    averageWaitTime: 35,
    doctors: 10,
    nurses: 20,
    equipment: []
  },
  {
    id: 'DEP005',
    name: 'Pediatrics',
    head: 'Dr. Kavitha Nair',
    totalBeds: 35,
    occupiedBeds: 25,
    waitingPatients: 10,
    averageWaitTime: 22,
    doctors: 7,
    nurses: 14,
    equipment: []
  },
  {
    id: 'DEP006',
    name: 'Emergency',
    head: 'Dr. Rahul Mehta',
    totalBeds: 40,
    occupiedBeds: 35,
    waitingPatients: 12,
    averageWaitTime: 10,
    doctors: 8,
    nurses: 16,
    equipment: []
  }
]

export const mockAppointments: Appointment[] = [
  {
    id: 'A001',
    patientId: 'P001',
    patientName: 'Rajesh Kumar',
    doctorId: 'D001',
    doctorName: 'Dr. Priya Sharma',
    department: 'Cardiology',
    date: '2024-03-15',
    time: '10:00',
    status: 'in-progress',
    type: 'follow-up',
    estimatedWaitTime: 15,
    queuePosition: 1
  },
  {
    id: 'A002',
    patientId: 'P002',
    patientName: 'Anjali Patel',
    doctorId: 'D004',
    doctorName: 'Dr. Sanjay Gupta',
    department: 'General Medicine',
    date: '2024-03-15',
    time: '10:30',
    status: 'checked-in',
    type: 'consultation',
    estimatedWaitTime: 25,
    queuePosition: 3
  },
  {
    id: 'A003',
    patientId: 'P003',
    patientName: 'Mohammed Ahmed',
    doctorId: 'D003',
    doctorName: 'Dr. Meera Reddy',
    department: 'Neurology',
    date: '2024-03-15',
    time: '11:00',
    status: 'scheduled',
    type: 'consultation',
    estimatedWaitTime: 40,
    queuePosition: 5
  }
]

export const mockQueue: QueueEntry[] = [
  { id: 'Q001', patientId: 'P001', patientName: 'Rajesh Kumar', department: 'Cardiology', priority: 'normal', checkInTime: '09:45', estimatedTime: '10:00', position: 1, status: 'in-progress', stressIndex: 2 },
  { id: 'Q002', patientId: 'P004', patientName: 'Sunita Devi', department: 'Cardiology', priority: 'urgent', checkInTime: '09:50', estimatedTime: '10:15', position: 2, status: 'waiting', stressIndex: 5 },
  { id: 'Q003', patientId: 'P002', patientName: 'Anjali Patel', department: 'General Medicine', priority: 'normal', checkInTime: '10:00', estimatedTime: '10:30', position: 3, status: 'waiting', stressIndex: 3 },
  { id: 'Q004', patientId: 'P005', patientName: 'Vikram Singh', department: 'General Medicine', priority: 'normal', checkInTime: '10:05', estimatedTime: '10:45', position: 4, status: 'waiting', stressIndex: 4 },
  { id: 'Q005', patientId: 'P003', patientName: 'Mohammed Ahmed', department: 'Neurology', priority: 'normal', checkInTime: '10:15', estimatedTime: '11:00', position: 5, status: 'waiting', stressIndex: 2 },
  { id: 'Q006', patientId: 'P006', patientName: 'Lakshmi Iyer', department: 'Pediatrics', priority: 'emergency', checkInTime: '10:20', estimatedTime: '10:25', position: 1, status: 'in-progress', stressIndex: 8 },
  { id: 'Q007', patientId: 'P007', patientName: 'Amit Sharma', department: 'Orthopedics', priority: 'normal', checkInTime: '10:10', estimatedTime: '10:40', position: 2, status: 'waiting', stressIndex: 3 },
  { id: 'Q008', patientId: 'P008', patientName: 'Priya Menon', department: 'Emergency', priority: 'emergency', checkInTime: '10:22', estimatedTime: '10:25', position: 1, status: 'in-progress', stressIndex: 9 }
]

export const mockResources: Resource[] = [
  { id: 'R001', name: 'Consultation Room 1', type: 'room', status: 'in-use', department: 'Cardiology', utilization: 85 },
  { id: 'R002', name: 'Consultation Room 2', type: 'room', status: 'available', department: 'Cardiology', utilization: 60 },
  { id: 'R003', name: 'ECG Machine', type: 'equipment', status: 'in-use', department: 'Cardiology', utilization: 90 },
  { id: 'R004', name: 'X-Ray Machine', type: 'equipment', status: 'available', department: 'Orthopedics', utilization: 70 },
  { id: 'R005', name: 'MRI Scanner', type: 'equipment', status: 'maintenance', department: 'Neurology', utilization: 0 },
  { id: 'R006', name: 'ICU Bed 1', type: 'bed', status: 'in-use', department: 'Emergency', utilization: 100 },
  { id: 'R007', name: 'ICU Bed 2', type: 'bed', status: 'in-use', department: 'Emergency', utilization: 100 },
  { id: 'R008', name: 'General Bed 1', type: 'bed', status: 'available', department: 'General Medicine', utilization: 0 },
  { id: 'R009', name: 'Ultrasound Machine', type: 'equipment', status: 'in-use', department: 'General Medicine', utilization: 75 },
  { id: 'R010', name: 'Ventilator', type: 'equipment', status: 'available', department: 'Emergency', utilization: 50 }
]

export const mockAIPredictions: AIprediction[] = [
  {
    department: 'Cardiology',
    predictedWaitTime: 28,
    confidence: 87,
    suggestedActions: ['Schedule additional morning slots', 'Consider telemedicine for follow-ups'],
    peakHours: ['10:00-12:00', '14:00-16:00'],
    staffingRecommendation: 'Add 1 nurse during peak hours'
  },
  {
    department: 'General Medicine',
    predictedWaitTime: 35,
    confidence: 92,
    suggestedActions: ['Implement fast-track for routine check-ups', 'Optimize appointment scheduling'],
    peakHours: ['09:00-11:00', '15:00-17:00'],
    staffingRecommendation: 'Add 2 doctors during morning peak'
  },
  {
    department: 'Emergency',
    predictedWaitTime: 12,
    confidence: 78,
    suggestedActions: ['Prepare additional trauma beds', 'Alert on-call surgeons'],
    peakHours: ['18:00-22:00', '08:00-10:00'],
    staffingRecommendation: 'Full staff required during peak'
  }
]

export const mockESI: EmotionalStressIndex[] = [
  {
    patientId: 'P006',
    score: 8,
    factors: { waitTime: 3, delays: 2, anxietyLevel: 5, painLevel: 4 },
    timestamp: '2024-03-15T10:20:00',
    alert: true
  },
  {
    patientId: 'P008',
    score: 9,
    factors: { waitTime: 1, delays: 0, anxietyLevel: 8, painLevel: 7 },
    timestamp: '2024-03-15T10:22:00',
    alert: true
  },
  {
    patientId: 'P004',
    score: 5,
    factors: { waitTime: 4, delays: 1, anxietyLevel: 3, painLevel: 2 },
    timestamp: '2024-03-15T09:50:00',
    alert: false
  }
]

export const dashboardStats = {
  totalPatients: 1247,
  todayAppointments: 156,
  averageWaitTime: 24,
  bedOccupancy: 78,
  staffOnDuty: 89,
  emergencyCases: 12,
  completedConsultations: 98,
  pendingLabReports: 34
}
