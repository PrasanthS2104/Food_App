export interface Patient {
  id: string
  name: string
  age: number
  gender: 'male' | 'female' | 'other'
  phone: string
  email: string
  bloodType: string
  allergies: string[]
  medicalHistory: MedicalRecord[]
  emergencyContact: {
    name: string
    phone: string
    relationship: string
  }
  insuranceId: string
  registrationDate: string
  profileImage?: string
}

export interface MedicalRecord {
  id: string
  date: string
  department: string
  doctor: string
  diagnosis: string
  prescription: Prescription[]
  notes: string
  vitals: VitalSigns
  labResults?: LabResult[]
}

export interface VitalSigns {
  bloodPressure: {
    systolic: number
    diastolic: number
  }
  heartRate: number
  temperature: number
  oxygenSaturation: number
  respiratoryRate: number
  weight?: number
  height?: number
  recordedAt: string
}

export interface Prescription {
  medication: string
  dosage: string
  frequency: string
  duration: string
  notes?: string
}

export interface LabResult {
  testName: string
  value: string
  unit: string
  normalRange: string
  status: 'normal' | 'abnormal' | 'critical'
}

export interface Appointment {
  id: string
  patientId: string
  patientName: string
  doctorId: string
  doctorName: string
  department: string
  date: string
  time: string
  status: 'scheduled' | 'checked-in' | 'in-progress' | 'completed' | 'cancelled'
  type: 'consultation' | 'follow-up' | 'emergency' | 'routine'
  notes?: string
  estimatedWaitTime?: number
  actualWaitTime?: number
  queuePosition?: number
}

export interface Doctor {
  id: string
  name: string
  specialization: string
  department: string
  qualification: string
  experience: number
  availableSlots: string[]
  currentPatients: number
  maxPatients: number
  status: 'available' | 'busy' | 'on-break' | 'off-duty'
  rating: number
  profileImage?: string
}

export interface Department {
  id: string
  name: string
  head: string
  totalBeds: number
  occupiedBeds: number
  waitingPatients: number
  averageWaitTime: number
  doctors: number
  nurses: number
  equipment: Equipment[]
}

export interface Equipment {
  id: string
  name: string
  type: string
  status: 'available' | 'in-use' | 'maintenance' | 'out-of-order'
  location: string
  lastMaintenance: string
  nextMaintenance: string
}

export interface QueueEntry {
  id: string
  patientId: string
  patientName: string
  department: string
  priority: 'normal' | 'urgent' | 'emergency'
  checkInTime: string
  estimatedTime: string
  position: number
  status: 'waiting' | 'in-progress' | 'completed'
  stressIndex?: number
}

export interface Resource {
  id: string
  name: string
  type: 'room' | 'equipment' | 'bed' | 'staff'
  status: 'available' | 'in-use' | 'maintenance'
  department: string
  utilization: number
}

export interface EmotionalStressIndex {
  patientId: string
  score: number
  factors: {
    waitTime: number
    delays: number
    anxietyLevel: number
    painLevel: number
  }
  timestamp: string
  alert: boolean
}

export interface AIprediction {
  department: string
  predictedWaitTime: number
  confidence: number
  suggestedActions: string[]
  peakHours: string[]
  staffingRecommendation: string
}

export interface SmartCard {
  patientQR: string
  staffQR: string
  patientId: string
  issuedAt: string
  expiresAt: string
  accessLevel: 'patient' | 'staff' | 'admin'
}
