import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter',
})

export const metadata: Metadata = {
  title: 'MedFlow Pro | Real-Time Patient Flow Management',
  description: 'Platform for Real-Time Mapping of Patient Flow & Resource Deployment. Smart patient tracking, vital signs monitoring, and AI-powered hospital management.',
  keywords: ['healthcare', 'hospital management', 'patient flow', 'medical', 'EHR', 'vital signs'],
}

export const viewport: Viewport = {
  themeColor: '#1a73e8',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="font-sans antialiased min-h-screen">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
