"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { 
  Activity, 
  Users, 
  Clock, 
  Shield, 
  Brain, 
  Stethoscope,
  ArrowRight,
  CheckCircle,
  BarChart3,
  Zap,
  Heart,
  Lock,
  ChevronRight,
  Star,
  Phone,
  Mail,
  MapPin
} from "lucide-react"

const features = [
  {
    icon: Brain,
    title: "AI-Powered Triage",
    description: "Machine learning algorithms assist in ESI level assignment and predict patient acuity with 95% accuracy."
  },
  {
    icon: Clock,
    title: "Real-Time Queue Management",
    description: "Dynamic patient flow tracking with intelligent waitlist optimization and automated notifications."
  },
  {
    icon: Shield,
    title: "Smart Patient Cards",
    description: "Digital patient identification with NFC/RFID integration for seamless tracking throughout the facility."
  },
  {
    icon: BarChart3,
    title: "Predictive Analytics",
    description: "Forecast patient volumes, optimize staffing, and identify bottlenecks before they impact care."
  },
  {
    icon: Stethoscope,
    title: "Clinician Dashboard",
    description: "Comprehensive view of assigned patients, vitals, medications, and care plans in one interface."
  },
  {
    icon: Zap,
    title: "Instant Alerts",
    description: "Critical patient status changes trigger immediate notifications to relevant care team members."
  },
]

const stats = [
  { value: "40%", label: "Reduction in Wait Times" },
  { value: "95%", label: "Triage Accuracy" },
  { value: "30%", label: "Improved Throughput" },
  { value: "99.9%", label: "System Uptime" },
]

const testimonials = [
  {
    quote: "MedFlow has transformed how we manage patient flow. Wait times are down significantly and patient satisfaction has never been higher.",
    author: "Dr. Sarah Chen",
    role: "Emergency Department Director",
    hospital: "Metro General Hospital"
  },
  {
    quote: "The AI-powered triage system helps our nurses make faster, more accurate decisions. It's become an indispensable tool.",
    author: "Michael Torres, RN",
    role: "Charge Nurse",
    hospital: "City Medical Center"
  },
  {
    quote: "Real-time analytics have given us visibility we never had before. We can now proactively manage capacity issues.",
    author: "Jennifer Walsh",
    role: "Chief Operating Officer",
    hospital: "Regional Health System"
  },
]

export default function HomePage() {
  const [email, setEmail] = useState("")

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <Activity className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">MedFlow</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#features" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Features
            </Link>
            <Link href="#solutions" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Solutions
            </Link>
            <Link href="#testimonials" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Testimonials
            </Link>
            <Link href="#contact" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Contact
            </Link>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild>
              <Link href="/dashboard">Sign In</Link>
            </Button>
            <Button asChild>
              <Link href="/dashboard">
                Get Started
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
        <div className="container relative py-24 md:py-32">
          <div className="mx-auto max-w-3xl text-center">
            <Badge className="mb-4" variant="secondary">
              Trusted by 500+ Healthcare Facilities
            </Badge>
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl text-balance">
              Intelligent Patient Flow Management for Modern Healthcare
            </h1>
            <p className="mt-6 text-lg text-muted-foreground text-pretty">
              Streamline emergency department operations with AI-powered triage, real-time tracking, 
              and predictive analytics. Reduce wait times, improve patient outcomes, and optimize resources.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" asChild>
                <Link href="/dashboard">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline">
                Schedule Demo
              </Button>
            </div>
          </div>

          {/* Hero Stats */}
          <div className="mx-auto mt-16 max-w-4xl">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-3xl font-bold text-primary">{stat.value}</div>
                  <div className="mt-1 text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-muted/30">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <Badge className="mb-4" variant="outline">Features</Badge>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Everything You Need to Optimize Patient Flow
            </h2>
            <p className="mt-4 text-muted-foreground">
              Comprehensive tools designed specifically for healthcare environments to improve 
              efficiency and patient care.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature) => {
              const Icon = feature.icon
              return (
                <Card key={feature.title} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4">
                      <Icon className="h-6 w-6" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-sm">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Solutions Section */}
      <section id="solutions" className="py-24">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4" variant="outline">Solutions</Badge>
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Built for Every Healthcare Setting
              </h2>
              <p className="mt-4 text-muted-foreground">
                From small urgent care centers to large hospital networks, MedFlow scales to meet your needs.
              </p>
              
              <div className="mt-8 space-y-4">
                {[
                  "Emergency Departments",
                  "Urgent Care Centers",
                  "Outpatient Clinics",
                  "Specialty Practices",
                  "Hospital Networks"
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-success" />
                    <span className="font-medium">{item}</span>
                  </div>
                ))}
              </div>

              <Button className="mt-8" size="lg">
                View All Solutions
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>

            <div className="grid gap-4">
              <Card className="border-primary/20 bg-primary/5">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Heart className="h-6 w-6 text-primary" />
                    <CardTitle>Patient-Centric Design</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Every feature is designed with patient experience in mind, reducing anxiety 
                    and improving satisfaction scores.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-success/20 bg-success/5">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Lock className="h-6 w-6 text-success" />
                    <CardTitle>HIPAA Compliant</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Enterprise-grade security with full HIPAA compliance, SOC 2 certification, 
                    and end-to-end encryption.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-info/20 bg-info/5">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Zap className="h-6 w-6 text-info" />
                    <CardTitle>Seamless Integration</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Connect with existing EHR systems, lab systems, and hospital infrastructure 
                    through our robust API.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 bg-muted/30">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <Badge className="mb-4" variant="outline">Testimonials</Badge>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Trusted by Healthcare Leaders
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-sm">
                <CardContent className="pt-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-warning text-warning" />
                    ))}
                  </div>
                  <p className="text-sm italic text-muted-foreground mb-6">
                    &quot;{testimonial.quote}&quot;
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{testimonial.author}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.hospital}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="container">
          <Card className="border-0 bg-primary text-primary-foreground overflow-hidden">
            <CardContent className="p-12">
              <div className="mx-auto max-w-2xl text-center">
                <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                  Ready to Transform Your Patient Flow?
                </h2>
                <p className="mt-4 text-primary-foreground/80">
                  Join 500+ healthcare facilities already using MedFlow to improve patient outcomes 
                  and operational efficiency.
                </p>
                <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
                  <div className="flex w-full max-w-md gap-2">
                    <Input 
                      type="email" 
                      placeholder="Enter your work email" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-white text-foreground"
                    />
                    <Button variant="secondary">
                      Get Started
                    </Button>
                  </div>
                </div>
                <p className="mt-4 text-xs text-primary-foreground/60">
                  Free 30-day trial. No credit card required.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-muted/30">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <Badge className="mb-4" variant="outline">Contact</Badge>
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Get in Touch
              </h2>
              <p className="mt-4 text-muted-foreground">
                Have questions? Our team is here to help you find the right solution for your healthcare facility.
              </p>
              
              <div className="mt-8 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Phone className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Call us</p>
                    <p className="font-medium">1-800-MEDFLOW</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Email us</p>
                    <p className="font-medium">hello@medflow.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Visit us</p>
                    <p className="font-medium">San Francisco, CA</p>
                  </div>
                </div>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Request a Demo</CardTitle>
                <CardDescription>
                  Fill out the form and our team will get back to you within 24 hours.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">First Name</label>
                    <Input placeholder="John" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Last Name</label>
                    <Input placeholder="Doe" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Work Email</label>
                  <Input type="email" placeholder="john@hospital.com" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Organization</label>
                  <Input placeholder="Hospital Name" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Message</label>
                  <Input placeholder="Tell us about your needs..." />
                </div>
                <Button className="w-full">
                  Submit Request
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <Activity className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-bold">MedFlow</span>
            </div>
            <p className="text-sm text-muted-foreground">
              2026 MedFlow Technologies. All rights reserved.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy Policy
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Terms of Service
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                HIPAA Compliance
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
