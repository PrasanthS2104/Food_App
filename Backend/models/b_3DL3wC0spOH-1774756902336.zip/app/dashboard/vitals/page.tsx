'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Heart,
  Activity,
  Thermometer,
  Wind,
  Droplets,
  Scale,
  Ruler,
  Plus,
  Search,
  Clock,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  TrendingDown
} from 'lucide-react'
import { mockPatients, mockQueue } from '@/lib/mock-data'

const recentVitals = [
  {
    id: 1,
    patientId: 'P001',
    patientName: 'Rajesh Kumar',
    recordedAt: '10:15 AM',
    bp: { systolic: 145, diastolic: 92 },
    heartRate: 78,
    temperature: 98.4,
    spo2: 98,
    respiratoryRate: 16,
    status: 'elevated'
  },
  {
    id: 2,
    patientId: 'P004',
    patientName: 'Sunita Devi',
    recordedAt: '10:05 AM',
    bp: { systolic: 120, diastolic: 80 },
    heartRate: 72,
    temperature: 98.6,
    spo2: 99,
    respiratoryRate: 14,
    status: 'normal'
  },
  {
    id: 3,
    patientId: 'P006',
    patientName: 'Lakshmi Iyer',
    recordedAt: '09:55 AM',
    bp: { systolic: 100, diastolic: 65 },
    heartRate: 110,
    temperature: 101.2,
    spo2: 94,
    respiratoryRate: 22,
    status: 'critical'
  },
  {
    id: 4,
    patientId: 'P002',
    patientName: 'Anjali Patel',
    recordedAt: '09:45 AM',
    bp: { systolic: 118, diastolic: 76 },
    heartRate: 68,
    temperature: 98.2,
    spo2: 98,
    respiratoryRate: 15,
    status: 'normal'
  }
]

export default function VitalsPage() {
  const [selectedPatient, setSelectedPatient] = useState('')
  const [showRecordDialog, setShowRecordDialog] = useState(false)
  const [vitalsForm, setVitalsForm] = useState({
    systolic: '',
    diastolic: '',
    heartRate: '',
    temperature: '',
    spo2: '',
    respiratoryRate: '',
    weight: '',
    height: ''
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'bg-success/10 text-success border-success/30'
      case 'elevated': return 'bg-warning/10 text-warning border-warning/30'
      case 'critical': return 'bg-destructive/10 text-destructive border-destructive/30'
      default: return 'bg-muted text-muted-foreground'
    }
  }

  const getVitalStatus = (type: string, value: number) => {
    switch (type) {
      case 'bp-systolic':
        if (value < 90) return { status: 'low', color: 'text-warning' }
        if (value > 140) return { status: 'high', color: 'text-destructive' }
        return { status: 'normal', color: 'text-success' }
      case 'heartRate':
        if (value < 60) return { status: 'low', color: 'text-warning' }
        if (value > 100) return { status: 'high', color: 'text-destructive' }
        return { status: 'normal', color: 'text-success' }
      case 'spo2':
        if (value < 95) return { status: 'low', color: 'text-destructive' }
        return { status: 'normal', color: 'text-success' }
      case 'temperature':
        if (value < 97) return { status: 'low', color: 'text-warning' }
        if (value > 99.5) return { status: 'high', color: 'text-destructive' }
        return { status: 'normal', color: 'text-success' }
      default:
        return { status: 'normal', color: 'text-success' }
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Vital Signs Monitor</h1>
          <p className="text-muted-foreground mt-1">Record and track patient vital signs at check-in</p>
        </div>
        <Dialog open={showRecordDialog} onOpenChange={setShowRecordDialog}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Record Vitals
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Record Vital Signs</DialogTitle>
            </DialogHeader>
            <div className="space-y-6 py-4">
              {/* Patient Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Select Patient</label>
                <Select value={selectedPatient} onValueChange={setSelectedPatient}>
                  <SelectTrigger>
                    <SelectValue placeholder="Search or select patient" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockPatients.map(p => (
                      <SelectItem key={p.id} value={p.id}>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarFallback className="text-xs bg-primary/10 text-primary">
                              {p.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          {p.name} ({p.id})
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Vitals Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Activity className="h-4 w-4 text-destructive" />
                    Blood Pressure (Systolic)
                  </label>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      placeholder="120"
                      value={vitalsForm.systolic}
                      onChange={(e) => setVitalsForm({...vitalsForm, systolic: e.target.value})}
                    />
                    <span className="text-sm text-muted-foreground">mmHg</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Activity className="h-4 w-4 text-destructive" />
                    Blood Pressure (Diastolic)
                  </label>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      placeholder="80"
                      value={vitalsForm.diastolic}
                      onChange={(e) => setVitalsForm({...vitalsForm, diastolic: e.target.value})}
                    />
                    <span className="text-sm text-muted-foreground">mmHg</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Heart className="h-4 w-4 text-destructive" />
                    Heart Rate
                  </label>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      placeholder="72"
                      value={vitalsForm.heartRate}
                      onChange={(e) => setVitalsForm({...vitalsForm, heartRate: e.target.value})}
                    />
                    <span className="text-sm text-muted-foreground">bpm</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Thermometer className="h-4 w-4 text-warning" />
                    Temperature
                  </label>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      step="0.1"
                      placeholder="98.6"
                      value={vitalsForm.temperature}
                      onChange={(e) => setVitalsForm({...vitalsForm, temperature: e.target.value})}
                    />
                    <span className="text-sm text-muted-foreground">°F</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Droplets className="h-4 w-4 text-primary" />
                    SpO2 (Oxygen Saturation)
                  </label>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      placeholder="98"
                      value={vitalsForm.spo2}
                      onChange={(e) => setVitalsForm({...vitalsForm, spo2: e.target.value})}
                    />
                    <span className="text-sm text-muted-foreground">%</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Wind className="h-4 w-4 text-accent" />
                    Respiratory Rate
                  </label>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      placeholder="16"
                      value={vitalsForm.respiratoryRate}
                      onChange={(e) => setVitalsForm({...vitalsForm, respiratoryRate: e.target.value})}
                    />
                    <span className="text-sm text-muted-foreground">breaths/min</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Scale className="h-4 w-4 text-muted-foreground" />
                    Weight
                  </label>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      placeholder="70"
                      value={vitalsForm.weight}
                      onChange={(e) => setVitalsForm({...vitalsForm, weight: e.target.value})}
                    />
                    <span className="text-sm text-muted-foreground">kg</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Ruler className="h-4 w-4 text-muted-foreground" />
                    Height
                  </label>
                  <div className="flex items-center gap-2">
                    <Input 
                      type="number" 
                      placeholder="170"
                      value={vitalsForm.height}
                      onChange={(e) => setVitalsForm({...vitalsForm, height: e.target.value})}
                    />
                    <span className="text-sm text-muted-foreground">cm</span>
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowRecordDialog(false)}>Cancel</Button>
              <Button onClick={() => setShowRecordDialog(false)}>Save Vitals</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Recorded Today</p>
                <p className="text-2xl font-bold">47</p>
              </div>
              <div className="p-2 rounded-lg bg-primary/10">
                <Activity className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Normal Range</p>
                <p className="text-2xl font-bold text-success">38</p>
              </div>
              <div className="p-2 rounded-lg bg-success/10">
                <CheckCircle className="h-5 w-5 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Elevated</p>
                <p className="text-2xl font-bold text-warning">6</p>
              </div>
              <div className="p-2 rounded-lg bg-warning/10">
                <TrendingUp className="h-5 w-5 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Critical</p>
                <p className="text-2xl font-bold text-destructive">3</p>
              </div>
              <div className="p-2 rounded-lg bg-destructive/10">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Vitals */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Recent Vital Recordings</CardTitle>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search patients..." className="pl-9 w-64" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-4">
            {recentVitals.map((vital) => (
              <div key={vital.id} className={`p-4 rounded-xl border ${
                vital.status === 'critical' ? 'border-destructive/50 bg-destructive/5' :
                vital.status === 'elevated' ? 'border-warning/50 bg-warning/5' :
                'border-border bg-card'
              }`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10 border-2 border-background">
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {vital.patientName.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{vital.patientName}</p>
                      <p className="text-xs text-muted-foreground">{vital.patientId}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {vital.recordedAt}
                      </p>
                    </div>
                    <Badge variant="outline" className={getStatusColor(vital.status)}>
                      {vital.status === 'critical' && <AlertTriangle className="h-3 w-3 mr-1" />}
                      {vital.status}
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-2 mb-1">
                      <Activity className="h-4 w-4 text-destructive" />
                      <span className="text-xs text-muted-foreground">BP</span>
                    </div>
                    <p className={`text-lg font-bold ${getVitalStatus('bp-systolic', vital.bp.systolic).color}`}>
                      {vital.bp.systolic}/{vital.bp.diastolic}
                    </p>
                    <p className="text-[10px] text-muted-foreground">mmHg</p>
                  </div>
                  
                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-2 mb-1">
                      <Heart className="h-4 w-4 text-destructive" />
                      <span className="text-xs text-muted-foreground">Heart Rate</span>
                    </div>
                    <p className={`text-lg font-bold ${getVitalStatus('heartRate', vital.heartRate).color}`}>
                      {vital.heartRate}
                    </p>
                    <p className="text-[10px] text-muted-foreground">bpm</p>
                  </div>

                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-2 mb-1">
                      <Thermometer className="h-4 w-4 text-warning" />
                      <span className="text-xs text-muted-foreground">Temp</span>
                    </div>
                    <p className={`text-lg font-bold ${getVitalStatus('temperature', vital.temperature).color}`}>
                      {vital.temperature}
                    </p>
                    <p className="text-[10px] text-muted-foreground">°F</p>
                  </div>

                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-2 mb-1">
                      <Droplets className="h-4 w-4 text-primary" />
                      <span className="text-xs text-muted-foreground">SpO2</span>
                    </div>
                    <p className={`text-lg font-bold ${getVitalStatus('spo2', vital.spo2).color}`}>
                      {vital.spo2}%
                    </p>
                    <p className="text-[10px] text-muted-foreground">Oxygen</p>
                  </div>

                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-2 mb-1">
                      <Wind className="h-4 w-4 text-accent" />
                      <span className="text-xs text-muted-foreground">Resp Rate</span>
                    </div>
                    <p className="text-lg font-bold">{vital.respiratoryRate}</p>
                    <p className="text-[10px] text-muted-foreground">breaths/min</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
