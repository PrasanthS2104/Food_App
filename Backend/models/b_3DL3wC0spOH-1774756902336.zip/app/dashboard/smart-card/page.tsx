'use client'

import { useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  QrCode,
  Download,
  Printer,
  RefreshCw,
  User,
  Shield,
  Calendar,
  Phone,
  Heart,
  AlertTriangle,
  CheckCircle,
  Scan,
  CreditCard,
  Search
} from 'lucide-react'
import { mockPatients } from '@/lib/mock-data'

function SmartCardContent() {
  const searchParams = useSearchParams()
  const patientId = searchParams.get('patient') || 'P001'
  const [selectedPatient, setSelectedPatient] = useState(patientId)
  const [scanMode, setScanMode] = useState<'patient' | 'staff'>('patient')
  
  const patient = mockPatients.find(p => p.id === selectedPatient) || mockPatients[0]
  
  // Generate QR code data (in real app, this would be encrypted)
  const patientQRData = `MEDFLOW-P:${patient.id}:${patient.name}:${Date.now()}`
  const staffQRData = `MEDFLOW-S:${patient.id}:VITALS:${Date.now()}`

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Smart Patient Card</h1>
          <p className="text-muted-foreground mt-1">Dual QR system for patient access and staff check-in</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedPatient} onValueChange={setSelectedPatient}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select patient" />
            </SelectTrigger>
            <SelectContent>
              {mockPatients.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name} ({p.id})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Physical Card Preview */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-primary" />
              Smart Card Preview
            </CardTitle>
          </CardHeader>
          <CardContent>
            {/* Card Front */}
            <div className="relative w-full aspect-[1.6/1] rounded-2xl bg-gradient-to-br from-primary via-primary/90 to-accent p-6 text-primary-foreground shadow-xl overflow-hidden">
              {/* Background pattern */}
              <div className="absolute inset-0 opacity-10">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                    <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" strokeWidth="0.5"/>
                  </pattern>
                  <rect width="100" height="100" fill="url(#grid)" />
                </svg>
              </div>
              
              {/* Logo */}
              <div className="absolute top-6 left-6 flex items-center gap-2">
                <div className="p-2 rounded-lg bg-primary-foreground/20">
                  <Heart className="h-5 w-5" />
                </div>
                <span className="font-bold text-lg">MedFlow Pro</span>
              </div>

              {/* Patient Info */}
              <div className="absolute bottom-6 left-6 right-24">
                <p className="text-xs opacity-80 uppercase tracking-wider">Patient Name</p>
                <p className="text-xl font-bold truncate">{patient.name}</p>
                <div className="flex items-center gap-4 mt-2">
                  <div>
                    <p className="text-xs opacity-80">ID</p>
                    <p className="font-mono font-semibold">{patient.id}</p>
                  </div>
                  <div>
                    <p className="text-xs opacity-80">Blood Type</p>
                    <p className="font-semibold">{patient.bloodType}</p>
                  </div>
                  <div>
                    <p className="text-xs opacity-80">DOB</p>
                    <p className="font-semibold">{patient.age}Y</p>
                  </div>
                </div>
              </div>

              {/* QR Code Area */}
              <div className="absolute bottom-6 right-6 p-2 bg-primary-foreground rounded-xl">
                <div className="w-16 h-16 bg-foreground/10 rounded-lg flex items-center justify-center">
                  <QrCode className="h-10 w-10 text-foreground" />
                </div>
              </div>

              {/* Valid indicator */}
              <div className="absolute top-6 right-6 flex items-center gap-1 text-xs bg-primary-foreground/20 px-2 py-1 rounded-full">
                <CheckCircle className="h-3 w-3" />
                <span>Valid</span>
              </div>
            </div>

            {/* Card Actions */}
            <div className="flex items-center gap-2 mt-4">
              <Button variant="outline" className="flex-1 gap-2">
                <Download className="h-4 w-4" />
                Download
              </Button>
              <Button variant="outline" className="flex-1 gap-2">
                <Printer className="h-4 w-4" />
                Print
              </Button>
              <Button variant="outline" size="icon">
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Dual QR System */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <QrCode className="h-5 w-5 text-primary" />
              Dual QR Code System
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={scanMode} onValueChange={(v) => setScanMode(v as 'patient' | 'staff')} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="patient" className="gap-2">
                  <User className="h-4 w-4" />
                  Patient QR
                </TabsTrigger>
                <TabsTrigger value="staff" className="gap-2">
                  <Shield className="h-4 w-4" />
                  Staff QR
                </TabsTrigger>
              </TabsList>

              <TabsContent value="patient" className="mt-4">
                <div className="text-center space-y-4">
                  <div className="inline-flex p-6 bg-card border-2 border-dashed border-primary/30 rounded-2xl">
                    {/* QR Code Placeholder - In production, use a QR library */}
                    <div className="w-48 h-48 bg-foreground rounded-xl flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-2 bg-background rounded-lg">
                        <div className="absolute inset-0 grid grid-cols-8 grid-rows-8 gap-0.5 p-2">
                          {Array.from({ length: 64 }).map((_, i) => (
                            <div 
                              key={i} 
                              className={`rounded-sm ${Math.random() > 0.5 ? 'bg-foreground' : 'bg-transparent'}`}
                            />
                          ))}
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="p-2 bg-background rounded-lg">
                            <Heart className="h-6 w-6 text-primary" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-semibold">Patient Access QR</h4>
                    <p className="text-sm text-muted-foreground max-w-sm mx-auto">
                      Scan to view medical history, appointments, queue position, and personal health records
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                    <h5 className="text-sm font-semibold text-primary mb-2">Features Accessible:</h5>
                    <div className="flex flex-wrap gap-2 justify-center">
                      <Badge variant="outline" className="bg-background">Medical History</Badge>
                      <Badge variant="outline" className="bg-background">Appointments</Badge>
                      <Badge variant="outline" className="bg-background">Queue Status</Badge>
                      <Badge variant="outline" className="bg-background">Lab Results</Badge>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="staff" className="mt-4">
                <div className="text-center space-y-4">
                  <div className="inline-flex p-6 bg-card border-2 border-dashed border-accent/30 rounded-2xl">
                    <div className="w-48 h-48 bg-foreground rounded-xl flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-2 bg-background rounded-lg">
                        <div className="absolute inset-0 grid grid-cols-8 grid-rows-8 gap-0.5 p-2">
                          {Array.from({ length: 64 }).map((_, i) => (
                            <div 
                              key={i} 
                              className={`rounded-sm ${Math.random() > 0.4 ? 'bg-foreground' : 'bg-transparent'}`}
                            />
                          ))}
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="p-2 bg-background rounded-lg">
                            <Shield className="h-6 w-6 text-accent" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-semibold">Staff Check-In QR</h4>
                    <p className="text-sm text-muted-foreground max-w-sm mx-auto">
                      Staff scan to record vital signs, check-in patient, and update patient status in real-time
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-accent/5 border border-accent/20">
                    <h5 className="text-sm font-semibold text-accent mb-2">Staff Actions:</h5>
                    <div className="flex flex-wrap gap-2 justify-center">
                      <Badge variant="outline" className="bg-background">Record Vitals</Badge>
                      <Badge variant="outline" className="bg-background">Check-In</Badge>
                      <Badge variant="outline" className="bg-background">Update Status</Badge>
                      <Badge variant="outline" className="bg-background">Add Notes</Badge>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Patient Quick Info */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-primary" />
            Card Holder Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-4 rounded-xl bg-muted/50">
              <Avatar className="h-12 w-12 border-2 border-primary/20">
                <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                  {patient.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold">{patient.name}</p>
                <p className="text-sm text-muted-foreground">{patient.age} years, {patient.gender}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 rounded-xl bg-muted/50">
              <div className="p-2 rounded-lg bg-primary/10">
                <Phone className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Contact</p>
                <p className="font-medium">{patient.phone}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 rounded-xl bg-muted/50">
              <div className="p-2 rounded-lg bg-destructive/10">
                <Heart className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Blood Type</p>
                <p className="font-medium">{patient.bloodType}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 rounded-xl bg-muted/50">
              <div className="p-2 rounded-lg bg-warning/10">
                <AlertTriangle className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Allergies</p>
                <p className="font-medium">
                  {patient.allergies.length > 0 ? patient.allergies.join(', ') : 'None'}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* QR Scanner */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Scan className="h-5 w-5 text-primary" />
            QR Scanner Mode
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-muted rounded-xl">
            <div className="p-4 rounded-full bg-primary/10 mb-4">
              <Scan className="h-8 w-8 text-primary" />
            </div>
            <h4 className="font-semibold text-lg">Scan Patient QR Code</h4>
            <p className="text-sm text-muted-foreground mt-2 text-center max-w-md">
              Use your device camera or a QR scanner to instantly access patient information and perform check-in operations
            </p>
            <Button className="mt-6 gap-2">
              <Scan className="h-4 w-4" />
              Activate Scanner
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default function SmartCardPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-64">Loading...</div>}>
      <SmartCardContent />
    </Suspense>
  )
}
