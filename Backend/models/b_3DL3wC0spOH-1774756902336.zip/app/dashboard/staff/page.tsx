"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { 
  Search, 
  Plus, 
  Filter, 
  Users, 
  UserCheck, 
  Clock, 
  Calendar,
  MoreVertical,
  Phone,
  Mail,
  MapPin,
  Stethoscope,
  Activity
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const staffMembers = [
  {
    id: "1",
    name: "Dr. Sarah Johnson",
    role: "Attending Physician",
    department: "Emergency",
    specialty: "Emergency Medicine",
    status: "on-duty",
    shift: "7:00 AM - 7:00 PM",
    patients: 8,
    maxPatients: 12,
    phone: "(555) 123-4567",
    email: "sarah.johnson@hospital.com",
    avatar: "/placeholder-user.jpg",
    yearsExp: 12
  },
  {
    id: "2",
    name: "Dr. Michael Chen",
    role: "Resident",
    department: "Emergency",
    specialty: "Internal Medicine",
    status: "on-duty",
    shift: "7:00 AM - 7:00 PM",
    patients: 5,
    maxPatients: 8,
    phone: "(555) 234-5678",
    email: "michael.chen@hospital.com",
    avatar: "/placeholder-user.jpg",
    yearsExp: 3
  },
  {
    id: "3",
    name: "Emily Rodriguez, RN",
    role: "Charge Nurse",
    department: "Emergency",
    specialty: "Critical Care",
    status: "on-duty",
    shift: "7:00 AM - 7:00 PM",
    patients: 6,
    maxPatients: 6,
    phone: "(555) 345-6789",
    email: "emily.rodriguez@hospital.com",
    avatar: "/placeholder-user.jpg",
    yearsExp: 8
  },
  {
    id: "4",
    name: "Dr. James Wilson",
    role: "Attending Physician",
    department: "Cardiology",
    specialty: "Cardiology",
    status: "on-call",
    shift: "On Call",
    patients: 0,
    maxPatients: 10,
    phone: "(555) 456-7890",
    email: "james.wilson@hospital.com",
    avatar: "/placeholder-user.jpg",
    yearsExp: 15
  },
  {
    id: "5",
    name: "Lisa Thompson, RN",
    role: "Staff Nurse",
    department: "Emergency",
    specialty: "Trauma",
    status: "on-duty",
    shift: "7:00 AM - 7:00 PM",
    patients: 4,
    maxPatients: 6,
    phone: "(555) 567-8901",
    email: "lisa.thompson@hospital.com",
    avatar: "/placeholder-user.jpg",
    yearsExp: 5
  },
  {
    id: "6",
    name: "Dr. Robert Kim",
    role: "Fellow",
    department: "Neurology",
    specialty: "Neurology",
    status: "off-duty",
    shift: "Off Duty",
    patients: 0,
    maxPatients: 8,
    phone: "(555) 678-9012",
    email: "robert.kim@hospital.com",
    avatar: "/placeholder-user.jpg",
    yearsExp: 6
  },
  {
    id: "7",
    name: "Maria Garcia, RN",
    role: "Staff Nurse",
    department: "Pediatrics",
    specialty: "Pediatric Care",
    status: "on-duty",
    shift: "7:00 AM - 7:00 PM",
    patients: 5,
    maxPatients: 6,
    phone: "(555) 789-0123",
    email: "maria.garcia@hospital.com",
    avatar: "/placeholder-user.jpg",
    yearsExp: 7
  },
  {
    id: "8",
    name: "Dr. Amanda Foster",
    role: "Attending Physician",
    department: "Orthopedics",
    specialty: "Orthopedic Surgery",
    status: "on-duty",
    shift: "8:00 AM - 6:00 PM",
    patients: 6,
    maxPatients: 10,
    phone: "(555) 890-1234",
    email: "amanda.foster@hospital.com",
    avatar: "/placeholder-user.jpg",
    yearsExp: 10
  },
]

const shiftSchedule = [
  { time: "7:00 AM", onDuty: 24, offDuty: 18, onCall: 8 },
  { time: "3:00 PM", onDuty: 22, offDuty: 20, onCall: 8 },
  { time: "11:00 PM", onDuty: 16, offDuty: 26, onCall: 8 },
]

export default function StaffPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredStaff = staffMembers.filter(staff => {
    const matchesSearch = staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          staff.role.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesDept = departmentFilter === "all" || staff.department === departmentFilter
    const matchesStatus = statusFilter === "all" || staff.status === statusFilter
    return matchesSearch && matchesDept && matchesStatus
  })

  const onDutyCount = staffMembers.filter(s => s.status === "on-duty").length
  const onCallCount = staffMembers.filter(s => s.status === "on-call").length
  const offDutyCount = staffMembers.filter(s => s.status === "off-duty").length

  const getStatusColor = (status: string) => {
    switch (status) {
      case "on-duty": return "bg-success/10 text-success"
      case "on-call": return "bg-warning/10 text-warning"
      case "off-duty": return "bg-muted text-muted-foreground"
      default: return "bg-muted text-muted-foreground"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Staff Management</h1>
          <p className="text-muted-foreground">
            Manage staff schedules, assignments, and workload distribution
          </p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Staff Member
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Staff</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{staffMembers.length}</div>
            <p className="text-xs text-muted-foreground">Active personnel</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">On Duty</CardTitle>
            <UserCheck className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">{onDutyCount}</div>
            <p className="text-xs text-muted-foreground">Currently working</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">On Call</CardTitle>
            <Phone className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">{onCallCount}</div>
            <p className="text-xs text-muted-foreground">Available if needed</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Off Duty</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{offDutyCount}</div>
            <p className="text-xs text-muted-foreground">Not scheduled</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="roster" className="space-y-4">
        <TabsList>
          <TabsTrigger value="roster">Staff Roster</TabsTrigger>
          <TabsTrigger value="schedule">Shift Schedule</TabsTrigger>
          <TabsTrigger value="workload">Workload</TabsTrigger>
        </TabsList>

        <TabsContent value="roster" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col gap-4 md:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input 
                    placeholder="Search staff by name or role..." 
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                  <SelectTrigger className="w-full md:w-[180px]">
                    <SelectValue placeholder="Department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    <SelectItem value="Emergency">Emergency</SelectItem>
                    <SelectItem value="Cardiology">Cardiology</SelectItem>
                    <SelectItem value="Neurology">Neurology</SelectItem>
                    <SelectItem value="Pediatrics">Pediatrics</SelectItem>
                    <SelectItem value="Orthopedics">Orthopedics</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full md:w-[150px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="on-duty">On Duty</SelectItem>
                    <SelectItem value="on-call">On Call</SelectItem>
                    <SelectItem value="off-duty">Off Duty</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Staff Grid */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredStaff.map((staff) => (
              <Card key={staff.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={staff.avatar} alt={staff.name} />
                        <AvatarFallback>{staff.name.split(" ").map(n => n[0]).join("")}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-base">{staff.name}</CardTitle>
                        <CardDescription className="text-xs">{staff.role}</CardDescription>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>View Profile</DropdownMenuItem>
                        <DropdownMenuItem>Edit Schedule</DropdownMenuItem>
                        <DropdownMenuItem>Send Message</DropdownMenuItem>
                        <DropdownMenuItem>Assign Patients</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Badge className={getStatusColor(staff.status)}>
                      {staff.status === "on-duty" ? "On Duty" : 
                       staff.status === "on-call" ? "On Call" : "Off Duty"}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{staff.shift}</span>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Stethoscope className="h-4 w-4 text-muted-foreground" />
                      <span>{staff.specialty}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{staff.department}</span>
                    </div>
                  </div>

                  {staff.status === "on-duty" && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Patient Load</span>
                        <span className="font-medium">{staff.patients}/{staff.maxPatients}</span>
                      </div>
                      <Progress 
                        value={(staff.patients / staff.maxPatients) * 100} 
                        className="h-2"
                      />
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Phone className="mr-1 h-3 w-3" />
                      Call
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <Mail className="mr-1 h-3 w-3" />
                      Message
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Today&apos;s Shift Schedule</CardTitle>
                  <CardDescription>Staff distribution across shifts</CardDescription>
                </div>
                <Button variant="outline">
                  <Calendar className="mr-2 h-4 w-4" />
                  View Full Schedule
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {shiftSchedule.map((shift, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{shift.time} Shift</h4>
                      <span className="text-sm text-muted-foreground">
                        {shift.onDuty + shift.onCall} staff available
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="rounded-lg border p-4">
                        <div className="flex items-center gap-2">
                          <div className="h-3 w-3 rounded-full bg-success" />
                          <span className="text-sm text-muted-foreground">On Duty</span>
                        </div>
                        <p className="mt-2 text-2xl font-bold">{shift.onDuty}</p>
                      </div>
                      <div className="rounded-lg border p-4">
                        <div className="flex items-center gap-2">
                          <div className="h-3 w-3 rounded-full bg-warning" />
                          <span className="text-sm text-muted-foreground">On Call</span>
                        </div>
                        <p className="mt-2 text-2xl font-bold">{shift.onCall}</p>
                      </div>
                      <div className="rounded-lg border p-4">
                        <div className="flex items-center gap-2">
                          <div className="h-3 w-3 rounded-full bg-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Off Duty</span>
                        </div>
                        <p className="mt-2 text-2xl font-bold">{shift.offDuty}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="workload" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Current Workload Distribution</CardTitle>
              <CardDescription>Patient assignments by staff member</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {staffMembers
                  .filter(s => s.status === "on-duty")
                  .sort((a, b) => (b.patients / b.maxPatients) - (a.patients / a.maxPatients))
                  .map((staff) => {
                    const loadPercentage = (staff.patients / staff.maxPatients) * 100
                    const isOverloaded = loadPercentage >= 90
                    const isHighLoad = loadPercentage >= 70
                    return (
                      <div key={staff.id} className="flex items-center gap-4">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={staff.avatar} alt={staff.name} />
                          <AvatarFallback>{staff.name.split(" ").map(n => n[0]).join("")}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{staff.name}</span>
                              <Badge variant="outline" className="text-xs">{staff.department}</Badge>
                            </div>
                            <span className={`text-sm font-medium ${
                              isOverloaded ? "text-destructive" : isHighLoad ? "text-warning" : "text-muted-foreground"
                            }`}>
                              {staff.patients}/{staff.maxPatients} patients
                            </span>
                          </div>
                          <Progress 
                            value={loadPercentage} 
                            className={`h-2 ${
                              isOverloaded ? "[&>div]:bg-destructive" : isHighLoad ? "[&>div]:bg-warning" : ""
                            }`}
                          />
                        </div>
                        <Button variant="ghost" size="sm">
                          <Activity className="h-4 w-4" />
                        </Button>
                      </div>
                    )
                  })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
