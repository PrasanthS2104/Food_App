'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Brain,
  TrendingUp,
  TrendingDown,
  Clock,
  Users,
  AlertTriangle,
  CheckCircle,
  Lightbulb,
  BarChart3,
  Activity,
  Heart,
  Zap,
  RefreshCw,
  ChevronRight,
  Building2
} from 'lucide-react'
import { mockAIPredictions, mockESI, mockDepartments, mockQueue } from '@/lib/mock-data'

export default function AIInsightsPage() {
  const [selectedTimeframe, setSelectedTimeframe] = useState('today')

  const highStressPatients = mockESI.filter(e => e.alert)
  const avgStressScore = Math.round(mockESI.reduce((acc, e) => acc + e.score, 0) / mockESI.length)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Brain className="h-6 w-6 text-primary" />
            AI Insights & Predictions
          </h1>
          <p className="text-muted-foreground mt-1">Machine learning powered analytics and stress monitoring</p>
        </div>
        <div className="flex items-center gap-2">
          <Tabs value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
            <TabsList>
              <TabsTrigger value="today">Today</TabsTrigger>
              <TabsTrigger value="week">This Week</TabsTrigger>
              <TabsTrigger value="month">This Month</TabsTrigger>
            </TabsList>
          </Tabs>
          <Button variant="outline" size="icon">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Brain className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">87%</p>
                <p className="text-xs text-muted-foreground">Prediction Accuracy</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <TrendingDown className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">-32%</p>
                <p className="text-xs text-muted-foreground">Wait Time Reduction</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-warning/10">
                <Heart className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{avgStressScore}/10</p>
                <p className="text-xs text-muted-foreground">Avg. Stress Index</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-destructive/10">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">{highStressPatients.length}</p>
                <p className="text-xs text-muted-foreground">High Stress Alerts</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* AI Predictions by Department */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              Wait Time Predictions
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            {mockAIPredictions.map((prediction, index) => (
              <div key={index} className="p-4 rounded-xl bg-muted/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Building2 className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold">{prediction.department}</p>
                      <p className="text-xs text-muted-foreground">
                        Confidence: {prediction.confidence}%
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-2xl font-bold ${
                      prediction.predictedWaitTime > 30 ? 'text-destructive' :
                      prediction.predictedWaitTime > 20 ? 'text-warning' :
                      'text-success'
                    }`}>
                      {prediction.predictedWaitTime} min
                    </p>
                    <p className="text-xs text-muted-foreground">Predicted Wait</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-muted-foreground">Peak Hours:</span>
                  {prediction.peakHours.map((hour, i) => (
                    <Badge key={i} variant="outline" className="text-xs">
                      {hour}
                    </Badge>
                  ))}
                </div>

                <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                  <div className="flex items-center gap-2 mb-2">
                    <Lightbulb className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium text-primary">AI Recommendation</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{prediction.staffingRecommendation}</p>
                </div>

                <div className="space-y-2">
                  <p className="text-xs font-medium">Suggested Actions:</p>
                  <div className="flex flex-wrap gap-2">
                    {prediction.suggestedActions.map((action, i) => (
                      <Badge key={i} className="bg-accent/10 text-accent border-0 text-xs">
                        {action}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Emotional Stress Index Monitor */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-destructive" />
                Emotional Stress Index (ESI)
              </CardTitle>
              <Badge className="bg-success/10 text-success border-0">
                <span className="h-2 w-2 rounded-full bg-success animate-pulse mr-1.5" />
                Live
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            {/* ESI Overview */}
            <div className="p-4 rounded-xl bg-muted/30">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium">Overall Patient Stress Level</span>
                <span className={`text-lg font-bold ${
                  avgStressScore >= 7 ? 'text-destructive' :
                  avgStressScore >= 4 ? 'text-warning' :
                  'text-success'
                }`}>
                  {avgStressScore}/10
                </span>
              </div>
              <Progress 
                value={avgStressScore * 10} 
                className={`h-3 ${
                  avgStressScore >= 7 ? 'bg-destructive/20' :
                  avgStressScore >= 4 ? 'bg-warning/20' :
                  'bg-success/20'
                }`}
              />
              <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                <span>Low Stress</span>
                <span>High Stress</span>
              </div>
            </div>

            {/* High Stress Alerts */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                High Stress Patients - Immediate Attention
              </h4>
              
              {mockESI.filter(e => e.alert).map((esi, index) => {
                const patient = mockQueue.find(q => q.patientId === esi.patientId)
                return (
                  <div key={index} className="p-4 rounded-xl border border-destructive/30 bg-destructive/5">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10 border-2 border-destructive/20">
                          <AvatarFallback className="bg-destructive/10 text-destructive">
                            {patient?.patientName.split(' ').map(n => n[0]).join('') || 'P'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{patient?.patientName || 'Patient'}</p>
                          <p className="text-xs text-muted-foreground">{esi.patientId}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-destructive">{esi.score}</p>
                        <p className="text-xs text-muted-foreground">ESI Score</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-2">
                      <div className="p-2 rounded-lg bg-background text-center">
                        <p className="text-xs text-muted-foreground">Wait Time</p>
                        <p className="font-semibold text-sm">{esi.factors.waitTime}/5</p>
                      </div>
                      <div className="p-2 rounded-lg bg-background text-center">
                        <p className="text-xs text-muted-foreground">Delays</p>
                        <p className="font-semibold text-sm">{esi.factors.delays}/5</p>
                      </div>
                      <div className="p-2 rounded-lg bg-background text-center">
                        <p className="text-xs text-muted-foreground">Anxiety</p>
                        <p className="font-semibold text-sm">{esi.factors.anxietyLevel}/10</p>
                      </div>
                      <div className="p-2 rounded-lg bg-background text-center">
                        <p className="text-xs text-muted-foreground">Pain</p>
                        <p className="font-semibold text-sm">{esi.factors.painLevel}/10</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      <span className="text-xs text-muted-foreground">
                        Last updated: {new Date(esi.timestamp).toLocaleTimeString()}
                      </span>
                      <Button size="sm" className="gap-1 bg-destructive hover:bg-destructive/90">
                        <Zap className="h-3 w-3" />
                        Priority Care
                      </Button>
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Normal Stress Patients */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-success" />
                Stable Patients
              </h4>
              
              {mockESI.filter(e => !e.alert).map((esi, index) => {
                const patient = mockQueue.find(q => q.patientId === esi.patientId)
                return (
                  <div key={index} className="p-3 rounded-xl bg-muted/30 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-success/10 text-success text-xs">
                          {patient?.patientName.split(' ').map(n => n[0]).join('') || 'P'}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-sm">{patient?.patientName || 'Patient'}</p>
                        <p className="text-xs text-muted-foreground">{esi.patientId}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className={`font-bold ${
                          esi.score >= 4 ? 'text-warning' : 'text-success'
                        }`}>
                          {esi.score}/10
                        </p>
                      </div>
                      <Progress 
                        value={esi.score * 10} 
                        className={`h-2 w-16 ${
                          esi.score >= 4 ? 'bg-warning/20' : 'bg-success/20'
                        }`}
                      />
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Optimization Suggestions */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-warning" />
            AI Optimization Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-success/5 border border-success/20">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-2 rounded-lg bg-success/10">
                  <TrendingDown className="h-5 w-5 text-success" />
                </div>
                <h4 className="font-semibold">Wait Time Optimization</h4>
              </div>
              <p className="text-sm text-muted-foreground mb-3">
                Implement fast-track lanes for routine check-ups to reduce average wait time by 15 minutes.
              </p>
              <div className="flex items-center justify-between">
                <Badge className="bg-success/10 text-success border-0">
                  High Impact
                </Badge>
                <Button size="sm" variant="ghost" className="gap-1 text-success">
                  Implement <ChevronRight className="h-3 w-3" />
                </Button>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <h4 className="font-semibold">Staff Reallocation</h4>
              </div>
              <p className="text-sm text-muted-foreground mb-3">
                Transfer 2 nurses from Pediatrics to General Medicine during peak hours (9-11 AM).
              </p>
              <div className="flex items-center justify-between">
                <Badge className="bg-primary/10 text-primary border-0">
                  Medium Impact
                </Badge>
                <Button size="sm" variant="ghost" className="gap-1 text-primary">
                  Review <ChevronRight className="h-3 w-3" />
                </Button>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-warning/5 border border-warning/20">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-2 rounded-lg bg-warning/10">
                  <Clock className="h-5 w-5 text-warning" />
                </div>
                <h4 className="font-semibold">Schedule Optimization</h4>
              </div>
              <p className="text-sm text-muted-foreground mb-3">
                Reschedule 20% of follow-ups to afternoon slots to balance patient load.
              </p>
              <div className="flex items-center justify-between">
                <Badge className="bg-warning/10 text-warning border-0">
                  Medium Impact
                </Badge>
                <Button size="sm" variant="ghost" className="gap-1 text-warning">
                  Analyze <ChevronRight className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Model Performance */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-accent" />
            AI Model Performance
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-muted/30 text-center">
              <p className="text-3xl font-bold text-primary">87%</p>
              <p className="text-sm text-muted-foreground mt-1">Wait Time Accuracy</p>
              <Progress value={87} className="h-1.5 mt-2" />
            </div>
            <div className="p-4 rounded-xl bg-muted/30 text-center">
              <p className="text-3xl font-bold text-success">92%</p>
              <p className="text-sm text-muted-foreground mt-1">ESI Detection</p>
              <Progress value={92} className="h-1.5 mt-2" />
            </div>
            <div className="p-4 rounded-xl bg-muted/30 text-center">
              <p className="text-3xl font-bold text-accent">78%</p>
              <p className="text-sm text-muted-foreground mt-1">Resource Prediction</p>
              <Progress value={78} className="h-1.5 mt-2" />
            </div>
            <div className="p-4 rounded-xl bg-muted/30 text-center">
              <p className="text-3xl font-bold text-warning">95%</p>
              <p className="text-sm text-muted-foreground mt-1">Peak Detection</p>
              <Progress value={95} className="h-1.5 mt-2" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
