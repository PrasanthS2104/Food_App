'use client'

import { use } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  ArrowLeft,
  QrCode,
  Calendar,
  Phone,
  Mail,
  MapPin,
  Heart,
  AlertTriangle,
  FileText,
  Pill,
  Activity,
  User,
  Shield,
  Clock
} from 'lucide-react'
import { mockPatients } from '@/lib/mock-data'
import Link from 'next/link'

export default function PatientDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const patient = mockPatients.find(p => p.id === id) || mockPatients[0]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard/patients">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-foreground">Patient Profile</h1>
          <p className="text-muted-foreground">Complete medical history and records</p>
        </div>
        <Button variant="outline" className="gap-2" asChild>
          <Link href={`/dashboard/smart-card?patient=${patient.id}`}>
            <QrCode className="h-4 w-4" />
            View Smart Card
          </Link>
        </Button>
        <Button className="gap-2">
          <Calendar className="h-4 w-4" />
          Book Appointment
        </Button>
      </div>

      {/* Patient Info Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="border-0 shadow-sm lg:col-span-1">
          <CardContent className="p-6">
            <div className="flex flex-col items-center text-center">
              <Avatar className="h-24 w-24 border-4 border-primary/20">
                <AvatarFallback className="bg-primary/10 text-primary text-2xl font-bold">
                  {patient.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <h2 className="mt-4 text-xl font-bold">{patient.name}</h2>
              <Badge variant="outline" className="mt-2 font-mono">{patient.id}</Badge>
              
              <div className="w-full mt-6 space-y-3">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div className="text-left">
                    <p className="text-xs text-muted-foreground">Age & Gender</p>
                    <p className="text-sm font-medium">{patient.age} years, {patient.gender}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Heart className="h-4 w-4 text-destructive" />
                  <div className="text-left">
                    <p className="text-xs text-muted-foreground">Blood Type</p>
                    <p className="text-sm font-medium">{patient.bloodType}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <div className="text-left">
                    <p className="text-xs text-muted-foreground">Phone</p>
                    <p className="text-sm font-medium">{patient.phone}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <div className="text-left">
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="text-sm font-medium truncate">{patient.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Shield className="h-4 w-4 text-muted-foreground" />
                  <div className="text-left">
                    <p className="text-xs text-muted-foreground">Insurance ID</p>
                    <p className="text-sm font-medium font-mono">{patient.insuranceId}</p>
                  </div>
                </div>
              </div>

              {/* Emergency Contact */}
              <div className="w-full mt-6 p-4 rounded-xl bg-destructive/5 border border-destructive/20">
                <h4 className="text-sm font-semibold text-destructive flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  Emergency Contact
                </h4>
                <div className="mt-2 text-left">
                  <p className="text-sm font-medium">{patient.emergencyContact.name}</p>
                  <p className="text-xs text-muted-foreground">{patient.emergencyContact.relationship}</p>
                  <p className="text-xs text-muted-foreground">{patient.emergencyContact.phone}</p>
                </div>
              </div>

              {/* Allergies */}
              {patient.allergies.length > 0 && (
                <div className="w-full mt-4 p-4 rounded-xl bg-warning/5 border border-warning/20">
                  <h4 className="text-sm font-semibold text-warning flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Known Allergies
                  </h4>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {patient.allergies.map((allergy, index) => (
                      <Badge key={index} variant="outline" className="border-warning/50 text-warning">
                        {allergy}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Medical Records */}
        <Card className="border-0 shadow-sm lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Medical Records
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="history" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="history">History</TabsTrigger>
                <TabsTrigger value="vitals">Vitals</TabsTrigger>
                <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
                <TabsTrigger value="labs">Lab Results</TabsTrigger>
              </TabsList>
              
              <TabsContent value="history" className="mt-4">
                <ScrollArea className="h-[400px] pr-4">
                  {patient.medicalHistory.length > 0 ? (
                    <div className="space-y-4">
                      {patient.medicalHistory.map((record) => (
                        <div key={record.id} className="p-4 rounded-xl border bg-card hover:shadow-sm transition-shadow">
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center gap-2">
                                <Badge className="bg-primary/10 text-primary border-0">{record.department}</Badge>
                                <span className="text-xs text-muted-foreground flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  {new Date(record.date).toLocaleDateString('en-IN', {
                                    day: 'numeric',
                                    month: 'short',
                                    year: 'numeric'
                                  })}
                                </span>
                              </div>
                              <h4 className="mt-2 font-semibold">{record.diagnosis}</h4>
                              <p className="text-sm text-muted-foreground mt-1">Attended by: {record.doctor}</p>
                            </div>
                          </div>
                          <p className="mt-3 text-sm text-muted-foreground">{record.notes}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-[300px] text-center">
                      <FileText className="h-12 w-12 text-muted-foreground/30" />
                      <p className="mt-4 text-muted-foreground">No medical history available</p>
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>

              <TabsContent value="vitals" className="mt-4">
                {patient.medicalHistory.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {(() => {
                      const vitals = patient.medicalHistory[0].vitals
                      return (
                        <>
                          <Card className="border bg-card">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                                <Activity className="h-4 w-4" />
                                <span className="text-xs">Blood Pressure</span>
                              </div>
                              <p className="text-2xl font-bold">
                                {vitals.bloodPressure.systolic}/{vitals.bloodPressure.diastolic}
                              </p>
                              <p className="text-xs text-muted-foreground">mmHg</p>
                            </CardContent>
                          </Card>
                          <Card className="border bg-card">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                                <Heart className="h-4 w-4" />
                                <span className="text-xs">Heart Rate</span>
                              </div>
                              <p className="text-2xl font-bold">{vitals.heartRate}</p>
                              <p className="text-xs text-muted-foreground">bpm</p>
                            </CardContent>
                          </Card>
                          <Card className="border bg-card">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                                <Activity className="h-4 w-4" />
                                <span className="text-xs">Temperature</span>
                              </div>
                              <p className="text-2xl font-bold">{vitals.temperature}</p>
                              <p className="text-xs text-muted-foreground">°F</p>
                            </CardContent>
                          </Card>
                          <Card className="border bg-card">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                                <Activity className="h-4 w-4" />
                                <span className="text-xs">Oxygen Saturation</span>
                              </div>
                              <p className="text-2xl font-bold">{vitals.oxygenSaturation}</p>
                              <p className="text-xs text-muted-foreground">%</p>
                            </CardContent>
                          </Card>
                          <Card className="border bg-card">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                                <Activity className="h-4 w-4" />
                                <span className="text-xs">Respiratory Rate</span>
                              </div>
                              <p className="text-2xl font-bold">{vitals.respiratoryRate}</p>
                              <p className="text-xs text-muted-foreground">breaths/min</p>
                            </CardContent>
                          </Card>
                          <Card className="border bg-card">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                                <User className="h-4 w-4" />
                                <span className="text-xs">Weight</span>
                              </div>
                              <p className="text-2xl font-bold">{vitals.weight || 'N/A'}</p>
                              <p className="text-xs text-muted-foreground">kg</p>
                            </CardContent>
                          </Card>
                        </>
                      )
                    })()}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-[300px] text-center">
                    <Activity className="h-12 w-12 text-muted-foreground/30" />
                    <p className="mt-4 text-muted-foreground">No vitals recorded</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="prescriptions" className="mt-4">
                {patient.medicalHistory.length > 0 && patient.medicalHistory[0].prescription.length > 0 ? (
                  <div className="space-y-3">
                    {patient.medicalHistory[0].prescription.map((rx, index) => (
                      <div key={index} className="p-4 rounded-xl border bg-card flex items-center gap-4">
                        <div className="p-3 rounded-lg bg-accent/10">
                          <Pill className="h-5 w-5 text-accent" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold">{rx.medication}</h4>
                          <p className="text-sm text-muted-foreground">
                            {rx.dosage} • {rx.frequency} • {rx.duration}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-[300px] text-center">
                    <Pill className="h-12 w-12 text-muted-foreground/30" />
                    <p className="mt-4 text-muted-foreground">No prescriptions found</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="labs" className="mt-4">
                <div className="flex flex-col items-center justify-center h-[300px] text-center">
                  <FileText className="h-12 w-12 text-muted-foreground/30" />
                  <p className="mt-4 text-muted-foreground">No lab results available</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
