"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  Users, 
  Activity, 
  Calendar,
  Download,
  Filter
} from "lucide-react"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts"

const patientFlowData = [
  { hour: "6AM", arrivals: 12, discharges: 5, inQueue: 18 },
  { hour: "8AM", arrivals: 28, discharges: 12, inQueue: 34 },
  { hour: "10AM", arrivals: 45, discharges: 25, inQueue: 54 },
  { hour: "12PM", arrivals: 38, discharges: 32, inQueue: 60 },
  { hour: "2PM", arrivals: 42, discharges: 35, inQueue: 67 },
  { hour: "4PM", arrivals: 35, discharges: 40, inQueue: 62 },
  { hour: "6PM", arrivals: 28, discharges: 30, inQueue: 60 },
  { hour: "8PM", arrivals: 22, discharges: 25, inQueue: 57 },
  { hour: "10PM", arrivals: 15, discharges: 18, inQueue: 54 },
]

const waitTimeData = [
  { department: "Emergency", avgWait: 45, target: 30 },
  { department: "Cardiology", avgWait: 25, target: 30 },
  { department: "Orthopedics", avgWait: 35, target: 30 },
  { department: "Pediatrics", avgWait: 20, target: 30 },
  { department: "Neurology", avgWait: 40, target: 30 },
  { department: "General", avgWait: 28, target: 30 },
]

const esiDistribution = [
  { name: "ESI 1 - Resuscitation", value: 5, color: "#dc2626" },
  { name: "ESI 2 - Emergent", value: 15, color: "#ea580c" },
  { name: "ESI 3 - Urgent", value: 35, color: "#ca8a04" },
  { name: "ESI 4 - Less Urgent", value: 30, color: "#2563eb" },
  { name: "ESI 5 - Non-Urgent", value: 15, color: "#16a34a" },
]

const weeklyTrends = [
  { day: "Mon", patients: 245, satisfaction: 4.2, efficiency: 87 },
  { day: "Tue", patients: 268, satisfaction: 4.3, efficiency: 89 },
  { day: "Wed", patients: 290, satisfaction: 4.1, efficiency: 85 },
  { day: "Thu", patients: 275, satisfaction: 4.4, efficiency: 91 },
  { day: "Fri", patients: 310, satisfaction: 4.0, efficiency: 82 },
  { day: "Sat", patients: 198, satisfaction: 4.5, efficiency: 93 },
  { day: "Sun", patients: 175, satisfaction: 4.6, efficiency: 95 },
]

const resourceUtilization = [
  { resource: "Beds", used: 85, total: 100 },
  { resource: "Ventilators", used: 12, total: 20 },
  { resource: "ICU Beds", used: 18, total: 25 },
  { resource: "OR Rooms", used: 6, total: 8 },
  { resource: "MRI", used: 2, total: 3 },
  { resource: "CT Scan", used: 3, total: 4 },
]

export default function AnalyticsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
          <p className="text-muted-foreground">
            Comprehensive insights into hospital operations and patient flow
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select defaultValue="today">
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Patients Today</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">287</div>
            <div className="flex items-center text-xs text-success">
              <TrendingUp className="mr-1 h-3 w-3" />
              +12% from yesterday
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Wait Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32 min</div>
            <div className="flex items-center text-xs text-destructive">
              <TrendingUp className="mr-1 h-3 w-3" />
              +5 min from target
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bed Occupancy</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85%</div>
            <div className="flex items-center text-xs text-warning">
              <TrendingUp className="mr-1 h-3 w-3" />
              Near capacity
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patient Satisfaction</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.3/5</div>
            <div className="flex items-center text-xs text-success">
              <TrendingUp className="mr-1 h-3 w-3" />
              +0.2 from last week
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="flow" className="space-y-4">
        <TabsList>
          <TabsTrigger value="flow">Patient Flow</TabsTrigger>
          <TabsTrigger value="wait">Wait Times</TabsTrigger>
          <TabsTrigger value="esi">ESI Distribution</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
        </TabsList>

        <TabsContent value="flow" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Hourly Patient Flow</CardTitle>
                <CardDescription>Arrivals, discharges, and queue status throughout the day</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={patientFlowData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="hour" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="arrivals" stackId="1" stroke="#2563eb" fill="#2563eb" fillOpacity={0.6} name="Arrivals" />
                    <Area type="monotone" dataKey="discharges" stackId="2" stroke="#16a34a" fill="#16a34a" fillOpacity={0.6} name="Discharges" />
                    <Line type="monotone" dataKey="inQueue" stroke="#dc2626" strokeWidth={2} dot={false} name="In Queue" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Weekly Trends</CardTitle>
                <CardDescription>Patient volume and efficiency metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={weeklyTrends}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="day" className="text-xs" />
                    <YAxis className="text-xs" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Line type="monotone" dataKey="patients" stroke="#2563eb" strokeWidth={2} name="Patients" />
                    <Line type="monotone" dataKey="efficiency" stroke="#16a34a" strokeWidth={2} name="Efficiency %" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="wait" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Department Wait Times</CardTitle>
              <CardDescription>Average wait time vs target (30 minutes)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={waitTimeData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis type="number" className="text-xs" />
                  <YAxis dataKey="department" type="category" className="text-xs" width={100} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Bar dataKey="avgWait" fill="#2563eb" name="Avg Wait (min)" radius={[0, 4, 4, 0]} />
                  <Bar dataKey="target" fill="#16a34a" name="Target (min)" radius={[0, 4, 4, 0]} fillOpacity={0.5} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="esi" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>ESI Level Distribution</CardTitle>
                <CardDescription>Current patient distribution by acuity level</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={esiDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                    >
                      {esiDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>ESI Level Details</CardTitle>
                <CardDescription>Breakdown of patients by severity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {esiDistribution.map((esi) => (
                    <div key={esi.name} className="flex items-center gap-4">
                      <div 
                        className="h-3 w-3 rounded-full" 
                        style={{ backgroundColor: esi.color }}
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{esi.name}</span>
                          <span className="text-sm text-muted-foreground">{esi.value}%</span>
                        </div>
                        <div className="mt-1 h-2 w-full rounded-full bg-muted">
                          <div 
                            className="h-2 rounded-full" 
                            style={{ width: `${esi.value}%`, backgroundColor: esi.color }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="resources" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Resource Utilization</CardTitle>
              <CardDescription>Current usage of hospital resources</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {resourceUtilization.map((resource) => {
                  const percentage = Math.round((resource.used / resource.total) * 100)
                  const getColor = () => {
                    if (percentage >= 90) return "text-destructive"
                    if (percentage >= 75) return "text-warning"
                    return "text-success"
                  }
                  return (
                    <div key={resource.resource} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{resource.resource}</span>
                        <Badge variant={percentage >= 90 ? "destructive" : percentage >= 75 ? "outline" : "secondary"}>
                          {resource.used}/{resource.total}
                        </Badge>
                      </div>
                      <div className="h-3 w-full rounded-full bg-muted">
                        <div 
                          className={`h-3 rounded-full transition-all ${
                            percentage >= 90 ? "bg-destructive" : percentage >= 75 ? "bg-warning" : "bg-success"
                          }`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <p className={`text-sm ${getColor()}`}>{percentage}% utilized</p>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
