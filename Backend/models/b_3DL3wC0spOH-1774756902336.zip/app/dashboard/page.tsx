import { StatsCards } from '@/components/dashboard/stats-cards'
import { QueueWidget } from '@/components/dashboard/queue-widget'
import { DepartmentOverview } from '@/components/dashboard/department-overview'
import { RecentActivity } from '@/components/dashboard/recent-activity'

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard Overview</h1>
          <p className="text-muted-foreground mt-1">
            Real-time patient flow and resource management
          </p>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-success/10 text-success">
            <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
            <span className="font-medium">System Online</span>
          </div>
          <span className="text-muted-foreground">Last updated: Just now</span>
        </div>
      </div>

      {/* Stats Grid */}
      <StatsCards />

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <QueueWidget />
        </div>
        <div className="space-y-6">
          <RecentActivity />
        </div>
      </div>

      {/* Department Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DepartmentOverview />
      </div>
    </div>
  )
}
