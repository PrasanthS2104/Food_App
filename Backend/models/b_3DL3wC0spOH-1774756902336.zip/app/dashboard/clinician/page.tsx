'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import {
  Stethoscope,
  Users,
  Clock,
  FileText,
  Activity,
  Heart,
  AlertTriangle,
  CheckCircle,
  Calendar,
  Pill,
  ChevronRight,
  User,
  Play,
  Pause,
  SkipForward
} from 'lucide-react'
import { mockPatients, mockDoctors, mockAppointments, mockQueue } from '@/lib/mock-data'

const currentDoctor = mockDoctors[0] // Dr. Priya Sharma

const todayPatients = [
  { id: 'P001', name: 'Rajesh Kumar', time: '10:00', status: 'in-progress', type: 'Follow-up', priority: 'normal' },
  { id: 'P004', name: 'Sunita Devi', time: '10:30', status: 'waiting', type: 'Consultation', priority: 'urgent' },
  { id: 'P009', name: 'Arun Mehta', time: '11:00', status: 'waiting', type: 'Check-up', priority: 'normal' },
  { id: 'P010', name: 'Geeta Sharma', time: '11:30', status: 'scheduled', type: 'Follow-up', priority: 'normal' },
  { id: 'P011', name: 'Vikash Singh', time: '14:00', status: 'scheduled', type: 'Consultation', priority: 'normal' },
  { id: 'P012', name: 'Meena Rao', time: '14:30', status: 'scheduled', type: 'Emergency', priority: 'emergency' },
]

export default function ClinicianDashboardPage() {
  const [selectedPatient, setSelectedPatient] = useState(mockPatients[0])
  const [consultationActive, setConsultationActive] = useState(true)

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in-progress': return 'bg-success/10 text-success border-success/30'
      case 'waiting': return 'bg-warning/10 text-warning border-warning/30'
      case 'scheduled': return 'bg-secondary text-secondary-foreground border-secondary'
      default: return 'bg-muted text-muted-foreground'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'emergency': return 'bg-destructive text-destructive-foreground'
      case 'urgent': return 'bg-warning text-warning-foreground'
      default: return 'bg-secondary text-secondary-foreground'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16 border-4 border-primary/20">
            <AvatarFallback className="bg-primary/10 text-primary text-xl font-bold">
              PS
            </AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{currentDoctor.name}</h1>
            <p className="text-muted-foreground">{currentDoctor.specialization} • {currentDoctor.department}</p>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className={currentDoctor.status === 'available' ? 'border-success text-success' : 'border-warning text-warning'}>
                {currentDoctor.status}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {currentDoctor.currentPatients}/{currentDoctor.maxPatients} patients today
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-2">
            <Pause className="h-4 w-4" />
            Take Break
          </Button>
          <Button className="gap-2">
            <SkipForward className="h-4 w-4" />
            Next Patient
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{todayPatients.length}</p>
                <p className="text-xs text-muted-foreground">Today&apos;s Patients</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <CheckCircle className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">3</p>
                <p className="text-xs text-muted-foreground">Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-warning/10">
                <Clock className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">25 min</p>
                <p className="text-xs text-muted-foreground">Avg. Consultation</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-destructive/10">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">1</p>
                <p className="text-xs text-muted-foreground">Emergency</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Patient Queue */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Calendar className="h-5 w-5 text-primary" />
              Today&apos;s Schedule
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-2">
                {todayPatients.map((patient, index) => (
                  <div
                    key={patient.id}
                    onClick={() => {
                      const found = mockPatients.find(p => p.id === patient.id)
                      if (found) setSelectedPatient(found)
                    }}
                    className={`p-4 rounded-xl cursor-pointer transition-all ${
                      selectedPatient.id === patient.id 
                        ? 'bg-primary/10 border-2 border-primary shadow-sm' 
                        : 'bg-muted/30 hover:bg-muted/50 border-2 border-transparent'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-medium">{patient.time}</span>
                        <Badge className={`text-[10px] ${getPriorityColor(patient.priority)}`}>
                          {patient.priority}
                        </Badge>
                      </div>
                      <Badge variant="outline" className={`text-[10px] ${getStatusColor(patient.status)}`}>
                        {patient.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10 border-2 border-background">
                        <AvatarFallback className="bg-secondary text-secondary-foreground text-sm">
                          {patient.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{patient.name}</p>
                        <p className="text-xs text-muted-foreground">{patient.type}</p>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Current Patient - Auto-Opening File */}
        <Card className="border-0 shadow-sm lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Stethoscope className="h-5 w-5 text-primary" />
                Patient File
                {consultationActive && (
                  <Badge className="bg-success/10 text-success border-0 ml-2">
                    <span className="h-2 w-2 rounded-full bg-success animate-pulse mr-1.5" />
                    Active
                  </Badge>
                )}
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  Full Records
                </Button>
                <Button size="sm">
                  <Pill className="h-4 w-4 mr-2" />
                  Prescribe
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {/* Patient Header */}
            <div className="flex items-start gap-4 p-4 rounded-xl bg-muted/30 mb-4">
              <Avatar className="h-16 w-16 border-2 border-primary/20">
                <AvatarFallback className="bg-primary/10 text-primary text-xl font-bold">
                  {selectedPatient.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-bold">{selectedPatient.name}</h3>
                  <Badge variant="outline" className="font-mono">{selectedPatient.id}</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {selectedPatient.age} years, {selectedPatient.gender} • Blood Type: {selectedPatient.bloodType}
                </p>
                <div className="flex items-center gap-4 mt-2">
                  <span className="text-sm text-muted-foreground">Insurance: {selectedPatient.insuranceId}</span>
                </div>
              </div>
              {selectedPatient.allergies.length > 0 && (
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20">
                  <div className="flex items-center gap-1 text-destructive text-xs font-semibold mb-1">
                    <AlertTriangle className="h-3 w-3" />
                    ALLERGIES
                  </div>
                  <p className="text-sm font-medium">{selectedPatient.allergies.join(', ')}</p>
                </div>
              )}
            </div>

            {/* Tabs for Patient Info */}
            <Tabs defaultValue="vitals" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="vitals">Latest Vitals</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
                <TabsTrigger value="medications">Medications</TabsTrigger>
                <TabsTrigger value="notes">Notes</TabsTrigger>
              </TabsList>

              <TabsContent value="vitals" className="mt-4">
                {selectedPatient.medicalHistory.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {(() => {
                      const vitals = selectedPatient.medicalHistory[0].vitals
                      return (
                        <>
                          <div className="p-4 rounded-xl bg-card border">
                            <div className="flex items-center gap-2 text-muted-foreground mb-2">
                              <Activity className="h-4 w-4" />
                              <span className="text-xs">Blood Pressure</span>
                            </div>
                            <p className="text-2xl font-bold">
                              {vitals.bloodPressure.systolic}/{vitals.bloodPressure.diastolic}
                            </p>
                            <p className="text-xs text-muted-foreground">mmHg</p>
                            <Progress 
                              value={(vitals.bloodPressure.systolic / 180) * 100} 
                              className="h-1.5 mt-2"
                            />
                          </div>
                          <div className="p-4 rounded-xl bg-card border">
                            <div className="flex items-center gap-2 text-muted-foreground mb-2">
                              <Heart className="h-4 w-4" />
                              <span className="text-xs">Heart Rate</span>
                            </div>
                            <p className="text-2xl font-bold">{vitals.heartRate}</p>
                            <p className="text-xs text-muted-foreground">bpm</p>
                            <Progress 
                              value={(vitals.heartRate / 120) * 100} 
                              className="h-1.5 mt-2"
                            />
                          </div>
                          <div className="p-4 rounded-xl bg-card border">
                            <div className="flex items-center gap-2 text-muted-foreground mb-2">
                              <Activity className="h-4 w-4" />
                              <span className="text-xs">SpO2</span>
                            </div>
                            <p className="text-2xl font-bold">{vitals.oxygenSaturation}%</p>
                            <p className="text-xs text-muted-foreground">Oxygen Saturation</p>
                            <Progress 
                              value={vitals.oxygenSaturation} 
                              className="h-1.5 mt-2"
                            />
                          </div>
                          <div className="p-4 rounded-xl bg-card border">
                            <div className="flex items-center gap-2 text-muted-foreground mb-2">
                              <Activity className="h-4 w-4" />
                              <span className="text-xs">Temperature</span>
                            </div>
                            <p className="text-2xl font-bold">{vitals.temperature}°F</p>
                            <p className="text-xs text-muted-foreground">Body Temperature</p>
                          </div>
                          <div className="p-4 rounded-xl bg-card border">
                            <div className="flex items-center gap-2 text-muted-foreground mb-2">
                              <Activity className="h-4 w-4" />
                              <span className="text-xs">Respiratory Rate</span>
                            </div>
                            <p className="text-2xl font-bold">{vitals.respiratoryRate}</p>
                            <p className="text-xs text-muted-foreground">breaths/min</p>
                          </div>
                          <div className="p-4 rounded-xl bg-card border">
                            <div className="flex items-center gap-2 text-muted-foreground mb-2">
                              <User className="h-4 w-4" />
                              <span className="text-xs">Weight</span>
                            </div>
                            <p className="text-2xl font-bold">{vitals.weight || 'N/A'}</p>
                            <p className="text-xs text-muted-foreground">kg</p>
                          </div>
                        </>
                      )
                    })()}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-[200px] text-center">
                    <Activity className="h-12 w-12 text-muted-foreground/30" />
                    <p className="mt-4 text-muted-foreground">No vitals recorded</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="history" className="mt-4">
                <ScrollArea className="h-[200px] pr-4">
                  {selectedPatient.medicalHistory.length > 0 ? (
                    <div className="space-y-3">
                      {selectedPatient.medicalHistory.map((record) => (
                        <div key={record.id} className="p-4 rounded-xl border bg-card">
                          <div className="flex items-center justify-between mb-2">
                            <Badge className="bg-primary/10 text-primary border-0">{record.department}</Badge>
                            <span className="text-xs text-muted-foreground">
                              {new Date(record.date).toLocaleDateString('en-IN')}
                            </span>
                          </div>
                          <h4 className="font-semibold">{record.diagnosis}</h4>
                          <p className="text-sm text-muted-foreground mt-1">{record.notes}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-[200px] text-center">
                      <FileText className="h-12 w-12 text-muted-foreground/30" />
                      <p className="mt-4 text-muted-foreground">No medical history</p>
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>

              <TabsContent value="medications" className="mt-4">
                {selectedPatient.medicalHistory.length > 0 && selectedPatient.medicalHistory[0].prescription.length > 0 ? (
                  <div className="space-y-3">
                    {selectedPatient.medicalHistory[0].prescription.map((rx, index) => (
                      <div key={index} className="flex items-center gap-4 p-4 rounded-xl border bg-card">
                        <div className="p-2 rounded-lg bg-accent/10">
                          <Pill className="h-5 w-5 text-accent" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold">{rx.medication}</h4>
                          <p className="text-sm text-muted-foreground">
                            {rx.dosage} • {rx.frequency} • {rx.duration}
                          </p>
                        </div>
                        <Badge variant="outline">Active</Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-[200px] text-center">
                    <Pill className="h-12 w-12 text-muted-foreground/30" />
                    <p className="mt-4 text-muted-foreground">No active medications</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="notes" className="mt-4">
                <div className="p-4 rounded-xl border bg-card min-h-[200px]">
                  <textarea
                    className="w-full h-32 bg-transparent resize-none focus:outline-none text-sm"
                    placeholder="Add consultation notes here..."
                  />
                  <div className="flex justify-end mt-2">
                    <Button size="sm">Save Notes</Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
