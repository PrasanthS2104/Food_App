'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Building2,
  Users,
  Bed,
  Clock,
  Stethoscope,
  Activity,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  ChevronRight,
  Settings
} from 'lucide-react'
import { mockDepartments, mockDoctors } from '@/lib/mock-data'

export default function DepartmentsPage() {
  const totalStats = {
    departments: mockDepartments.length,
    totalBeds: mockDepartments.reduce((acc, d) => acc + d.totalBeds, 0),
    occupiedBeds: mockDepartments.reduce((acc, d) => acc + d.occupiedBeds, 0),
    totalDoctors: mockDepartments.reduce((acc, d) => acc + d.doctors, 0),
    totalNurses: mockDepartments.reduce((acc, d) => acc + d.nurses, 0),
    totalWaiting: mockDepartments.reduce((acc, d) => acc + d.waitingPatients, 0)
  }

  const overallOccupancy = Math.round((totalStats.occupiedBeds / totalStats.totalBeds) * 100)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Departments</h1>
          <p className="text-muted-foreground mt-1">Cross-department overview and resource management</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Settings className="h-4 w-4" />
          Manage Departments
        </Button>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Building2 className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalStats.departments}</p>
                <p className="text-xs text-muted-foreground">Departments</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/10">
                <Bed className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalStats.occupiedBeds}/{totalStats.totalBeds}</p>
                <p className="text-xs text-muted-foreground">Beds Occupied</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-warning/10">
                <Activity className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{overallOccupancy}%</p>
                <p className="text-xs text-muted-foreground">Overall Occupancy</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <Stethoscope className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalStats.totalDoctors}</p>
                <p className="text-xs text-muted-foreground">Total Doctors</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalStats.totalNurses}</p>
                <p className="text-xs text-muted-foreground">Total Nurses</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-destructive/10">
                <Clock className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalStats.totalWaiting}</p>
                <p className="text-xs text-muted-foreground">Total Waiting</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Department Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockDepartments.map((dept) => {
          const occupancyPercent = Math.round((dept.occupiedBeds / dept.totalBeds) * 100)
          const occupancyStatus = occupancyPercent >= 90 ? 'critical' : occupancyPercent >= 70 ? 'warning' : 'normal'
          
          return (
            <Card key={dept.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-xl ${
                      dept.name === 'Emergency' ? 'bg-destructive/10' :
                      dept.name === 'Cardiology' ? 'bg-primary/10' :
                      'bg-accent/10'
                    }`}>
                      <Building2 className={`h-6 w-6 ${
                        dept.name === 'Emergency' ? 'text-destructive' :
                        dept.name === 'Cardiology' ? 'text-primary' :
                        'text-accent'
                      }`} />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{dept.name}</CardTitle>
                      <p className="text-xs text-muted-foreground mt-0.5">{dept.head}</p>
                    </div>
                  </div>
                  <Badge variant="outline" className={
                    occupancyStatus === 'critical' ? 'border-destructive text-destructive' :
                    occupancyStatus === 'warning' ? 'border-warning text-warning' :
                    'border-success text-success'
                  }>
                    {occupancyPercent}%
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-0 space-y-4">
                {/* Bed Occupancy */}
                <div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="flex items-center gap-1.5 text-muted-foreground">
                      <Bed className="h-4 w-4" />
                      Bed Occupancy
                    </span>
                    <span className="font-medium">{dept.occupiedBeds}/{dept.totalBeds}</span>
                  </div>
                  <Progress 
                    value={occupancyPercent} 
                    className={`h-2 ${
                      occupancyStatus === 'critical' ? 'bg-destructive/20' :
                      occupancyStatus === 'warning' ? 'bg-warning/20' :
                      'bg-success/20'
                    }`}
                  />
                </div>

                {/* Staff & Wait Info */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-2 mb-1">
                      <Stethoscope className="h-4 w-4 text-primary" />
                      <span className="text-xs text-muted-foreground">Doctors</span>
                    </div>
                    <p className="text-lg font-bold">{dept.doctors}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-2 mb-1">
                      <Users className="h-4 w-4 text-accent" />
                      <span className="text-xs text-muted-foreground">Nurses</span>
                    </div>
                    <p className="text-lg font-bold">{dept.nurses}</p>
                  </div>
                </div>

                {/* Wait Time & Patients */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Avg. Wait:</span>
                    <span className={`font-semibold ${
                      dept.averageWaitTime > 30 ? 'text-destructive' :
                      dept.averageWaitTime > 20 ? 'text-warning' :
                      'text-success'
                    }`}>
                      {dept.averageWaitTime} min
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    {dept.averageWaitTime > 25 ? (
                      <TrendingUp className="h-4 w-4 text-destructive" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-success" />
                    )}
                  </div>
                </div>

                {/* Waiting Patients */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className={`h-4 w-4 ${
                      dept.waitingPatients > 10 ? 'text-destructive' :
                      dept.waitingPatients > 5 ? 'text-warning' :
                      'text-success'
                    }`} />
                    <span className="text-sm text-muted-foreground">
                      {dept.waitingPatients} patients waiting
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" className="gap-1 text-primary">
                    Details <ChevronRight className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Doctors Overview */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Stethoscope className="h-5 w-5 text-primary" />
            Active Doctors
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockDoctors.map((doctor) => (
              <div key={doctor.id} className="flex items-center gap-4 p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors">
                <Avatar className="h-12 w-12 border-2 border-primary/20">
                  <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                    {doctor.name.replace('Dr. ', '').split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{doctor.name}</p>
                  <p className="text-sm text-muted-foreground">{doctor.specialization}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className={
                      doctor.status === 'available' ? 'border-success text-success' :
                      doctor.status === 'busy' ? 'border-warning text-warning' :
                      'border-muted-foreground text-muted-foreground'
                    }>
                      {doctor.status}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {doctor.currentPatients}/{doctor.maxPatients} patients
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1">
                    <span className="text-lg font-bold">{doctor.rating}</span>
                    <span className="text-warning">★</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{doctor.experience}y exp</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
