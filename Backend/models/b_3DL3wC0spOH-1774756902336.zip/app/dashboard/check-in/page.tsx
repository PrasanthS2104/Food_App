"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { 
  UserPlus, 
  CreditCard, 
  FileText, 
  Stethoscope,
  CheckCircle,
  AlertCircle,
  ChevronRight,
  ChevronLeft,
  Search,
  Scan
} from "lucide-react"

const steps = [
  { id: 1, title: "Patient Info", icon: UserPlus },
  { id: 2, title: "Insurance", icon: CreditCard },
  { id: 3, title: "Chief Complaint", icon: FileText },
  { id: 4, title: "Triage", icon: Stethoscope },
  { id: 5, title: "Confirmation", icon: CheckCircle },
]

export default function CheckInPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [patientType, setPatientType] = useState<"new" | "returning">("new")
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    dob: "",
    gender: "",
    phone: "",
    email: "",
    address: "",
    emergencyContact: "",
    emergencyPhone: "",
    insuranceProvider: "",
    policyNumber: "",
    groupNumber: "",
    subscriberName: "",
    chiefComplaint: "",
    painLevel: "",
    symptoms: [] as string[],
    allergies: "",
    currentMedications: "",
    esiLevel: "",
    bloodPressure: "",
    heartRate: "",
    temperature: "",
    oxygenSat: "",
  })

  const progress = (currentStep / steps.length) * 100

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const updateFormData = (field: string, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const symptomOptions = [
    "Chest Pain", "Shortness of Breath", "Headache", "Fever",
    "Nausea/Vomiting", "Abdominal Pain", "Dizziness", "Back Pain",
    "Cough", "Fatigue", "Injury/Trauma", "Other"
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Patient Check-In</h1>
          <p className="text-muted-foreground">
            Register new patients or check in returning patients
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline">
            <Scan className="mr-2 h-4 w-4" />
            Scan ID/Insurance
          </Button>
          <Button variant="outline">
            <Search className="mr-2 h-4 w-4" />
            Find Patient
          </Button>
        </div>
      </div>

      {/* Progress Stepper */}
      <Card>
        <CardContent className="pt-6">
          <div className="mb-4">
            <Progress value={progress} className="h-2" />
          </div>
          <div className="flex justify-between">
            {steps.map((step) => {
              const Icon = step.icon
              const isActive = currentStep === step.id
              const isComplete = currentStep > step.id
              return (
                <div 
                  key={step.id}
                  className={`flex flex-col items-center gap-2 ${
                    isActive ? "text-primary" : isComplete ? "text-success" : "text-muted-foreground"
                  }`}
                >
                  <div className={`flex h-10 w-10 items-center justify-center rounded-full border-2 ${
                    isActive ? "border-primary bg-primary text-primary-foreground" : 
                    isComplete ? "border-success bg-success text-white" : "border-muted"
                  }`}>
                    {isComplete ? <CheckCircle className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
                  </div>
                  <span className="text-xs font-medium hidden sm:block">{step.title}</span>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Patient Type Selection */}
      {currentStep === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Patient Information</CardTitle>
            <CardDescription>Enter patient details or search for existing records</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex gap-4">
              <Button 
                variant={patientType === "new" ? "default" : "outline"}
                onClick={() => setPatientType("new")}
                className="flex-1"
              >
                <UserPlus className="mr-2 h-4 w-4" />
                New Patient
              </Button>
              <Button 
                variant={patientType === "returning" ? "default" : "outline"}
                onClick={() => setPatientType("returning")}
                className="flex-1"
              >
                <Search className="mr-2 h-4 w-4" />
                Returning Patient
              </Button>
            </div>

            <Separator />

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name *</Label>
                <Input 
                  id="firstName" 
                  value={formData.firstName}
                  onChange={(e) => updateFormData("firstName", e.target.value)}
                  placeholder="Enter first name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name *</Label>
                <Input 
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => updateFormData("lastName", e.target.value)}
                  placeholder="Enter last name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dob">Date of Birth *</Label>
                <Input 
                  id="dob" 
                  type="date"
                  value={formData.dob}
                  onChange={(e) => updateFormData("dob", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Gender *</Label>
                <Select value={formData.gender} onValueChange={(v) => updateFormData("gender", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                    <SelectItem value="prefer-not">Prefer not to say</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input 
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => updateFormData("phone", e.target.value)}
                  placeholder="(555) 123-4567"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateFormData("email", e.target.value)}
                  placeholder="patient@email.com"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="address">Address</Label>
                <Input 
                  id="address"
                  value={formData.address}
                  onChange={(e) => updateFormData("address", e.target.value)}
                  placeholder="Street, City, State, ZIP"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="emergencyContact">Emergency Contact Name</Label>
                <Input 
                  id="emergencyContact"
                  value={formData.emergencyContact}
                  onChange={(e) => updateFormData("emergencyContact", e.target.value)}
                  placeholder="Full name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="emergencyPhone">Emergency Contact Phone</Label>
                <Input 
                  id="emergencyPhone"
                  type="tel"
                  value={formData.emergencyPhone}
                  onChange={(e) => updateFormData("emergencyPhone", e.target.value)}
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Insurance Information */}
      {currentStep === 2 && (
        <Card>
          <CardHeader>
            <CardTitle>Insurance Information</CardTitle>
            <CardDescription>Enter insurance details or select self-pay</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Insurance Provider</Label>
                <Select value={formData.insuranceProvider} onValueChange={(v) => updateFormData("insuranceProvider", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bluecross">Blue Cross Blue Shield</SelectItem>
                    <SelectItem value="aetna">Aetna</SelectItem>
                    <SelectItem value="cigna">Cigna</SelectItem>
                    <SelectItem value="united">UnitedHealthcare</SelectItem>
                    <SelectItem value="kaiser">Kaiser Permanente</SelectItem>
                    <SelectItem value="medicare">Medicare</SelectItem>
                    <SelectItem value="medicaid">Medicaid</SelectItem>
                    <SelectItem value="selfpay">Self-Pay</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="policyNumber">Policy Number</Label>
                <Input 
                  id="policyNumber"
                  value={formData.policyNumber}
                  onChange={(e) => updateFormData("policyNumber", e.target.value)}
                  placeholder="Enter policy number"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="groupNumber">Group Number</Label>
                <Input 
                  id="groupNumber"
                  value={formData.groupNumber}
                  onChange={(e) => updateFormData("groupNumber", e.target.value)}
                  placeholder="Enter group number"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subscriberName">Subscriber Name</Label>
                <Input 
                  id="subscriberName"
                  value={formData.subscriberName}
                  onChange={(e) => updateFormData("subscriberName", e.target.value)}
                  placeholder="Primary subscriber name"
                />
              </div>
            </div>

            <div className="rounded-lg border border-info/50 bg-info/5 p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-info mt-0.5" />
                <div>
                  <p className="font-medium text-info">Insurance Verification</p>
                  <p className="text-sm text-muted-foreground">
                    Insurance details will be verified automatically. Additional co-pay information will be provided after verification.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Chief Complaint */}
      {currentStep === 3 && (
        <Card>
          <CardHeader>
            <CardTitle>Chief Complaint</CardTitle>
            <CardDescription>Describe the primary reason for the visit</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="chiefComplaint">Primary Complaint *</Label>
              <Textarea 
                id="chiefComplaint"
                value={formData.chiefComplaint}
                onChange={(e) => updateFormData("chiefComplaint", e.target.value)}
                placeholder="Describe the main reason for today's visit..."
                rows={4}
              />
            </div>

            <div className="space-y-4">
              <Label>Pain Level (0-10)</Label>
              <RadioGroup 
                value={formData.painLevel} 
                onValueChange={(v) => updateFormData("painLevel", v)}
                className="flex flex-wrap gap-2"
              >
                {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => (
                  <div key={level} className="flex items-center">
                    <RadioGroupItem value={level.toString()} id={`pain-${level}`} className="peer sr-only" />
                    <Label 
                      htmlFor={`pain-${level}`}
                      className={`flex h-10 w-10 cursor-pointer items-center justify-center rounded-full border-2 font-medium transition-colors peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary peer-data-[state=checked]:text-primary-foreground ${
                        level <= 3 ? "hover:border-success" : level <= 6 ? "hover:border-warning" : "hover:border-destructive"
                      }`}
                    >
                      {level}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label>Symptoms (select all that apply)</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {symptomOptions.map((symptom) => (
                  <div key={symptom} className="flex items-center space-x-2">
                    <Checkbox 
                      id={symptom}
                      checked={formData.symptoms.includes(symptom)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          updateFormData("symptoms", [...formData.symptoms, symptom])
                        } else {
                          updateFormData("symptoms", formData.symptoms.filter(s => s !== symptom))
                        }
                      }}
                    />
                    <Label htmlFor={symptom} className="text-sm cursor-pointer">{symptom}</Label>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="allergies">Known Allergies</Label>
                <Textarea 
                  id="allergies"
                  value={formData.allergies}
                  onChange={(e) => updateFormData("allergies", e.target.value)}
                  placeholder="List any known allergies..."
                  rows={2}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="medications">Current Medications</Label>
                <Textarea 
                  id="medications"
                  value={formData.currentMedications}
                  onChange={(e) => updateFormData("currentMedications", e.target.value)}
                  placeholder="List current medications..."
                  rows={2}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Triage */}
      {currentStep === 4 && (
        <Card>
          <CardHeader>
            <CardTitle>Triage Assessment</CardTitle>
            <CardDescription>Record vital signs and assign ESI level</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-2">
                <Label htmlFor="bloodPressure">Blood Pressure</Label>
                <Input 
                  id="bloodPressure"
                  value={formData.bloodPressure}
                  onChange={(e) => updateFormData("bloodPressure", e.target.value)}
                  placeholder="120/80 mmHg"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="heartRate">Heart Rate</Label>
                <Input 
                  id="heartRate"
                  value={formData.heartRate}
                  onChange={(e) => updateFormData("heartRate", e.target.value)}
                  placeholder="72 bpm"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="temperature">Temperature</Label>
                <Input 
                  id="temperature"
                  value={formData.temperature}
                  onChange={(e) => updateFormData("temperature", e.target.value)}
                  placeholder="98.6 F"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="oxygenSat">Oxygen Saturation</Label>
                <Input 
                  id="oxygenSat"
                  value={formData.oxygenSat}
                  onChange={(e) => updateFormData("oxygenSat", e.target.value)}
                  placeholder="98%"
                />
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <Label>ESI Level Assignment *</Label>
              <RadioGroup 
                value={formData.esiLevel} 
                onValueChange={(v) => updateFormData("esiLevel", v)}
                className="space-y-3"
              >
                {[
                  { level: "1", name: "Resuscitation", desc: "Immediate life-saving intervention required", color: "destructive" },
                  { level: "2", name: "Emergent", desc: "High risk situation or severe pain/distress", color: "warning" },
                  { level: "3", name: "Urgent", desc: "Requires multiple resources, stable vital signs", color: "warning" },
                  { level: "4", name: "Less Urgent", desc: "Requires one resource, non-urgent", color: "info" },
                  { level: "5", name: "Non-Urgent", desc: "No resources needed, minor complaint", color: "success" },
                ].map((esi) => (
                  <div key={esi.level} className="flex items-center space-x-3">
                    <RadioGroupItem value={esi.level} id={`esi-${esi.level}`} />
                    <Label htmlFor={`esi-${esi.level}`} className="flex-1 cursor-pointer">
                      <div className="flex items-center gap-2">
                        <Badge variant={esi.color === "destructive" ? "destructive" : esi.color === "success" ? "outline" : "secondary"}>
                          ESI {esi.level}
                        </Badge>
                        <span className="font-medium">{esi.name}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{esi.desc}</p>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Confirmation */}
      {currentStep === 5 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-6 w-6 text-success" />
              Check-In Complete
            </CardTitle>
            <CardDescription>Review and confirm patient information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-4">
                <h4 className="font-semibold">Patient Information</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Name:</span>
                    <span>{formData.firstName} {formData.lastName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">DOB:</span>
                    <span>{formData.dob || "Not provided"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Phone:</span>
                    <span>{formData.phone || "Not provided"}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Insurance</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Provider:</span>
                    <span>{formData.insuranceProvider || "Self-Pay"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Policy #:</span>
                    <span>{formData.policyNumber || "N/A"}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Chief Complaint</h4>
                <p className="text-sm">{formData.chiefComplaint || "Not provided"}</p>
                {formData.symptoms.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {formData.symptoms.map(symptom => (
                      <Badge key={symptom} variant="secondary" className="text-xs">{symptom}</Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Triage</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">ESI Level:</span>
                    <Badge>{formData.esiLevel ? `ESI ${formData.esiLevel}` : "Not assigned"}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Vitals:</span>
                    <span>Recorded</span>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            <div className="rounded-lg border border-success/50 bg-success/5 p-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-success mt-0.5" />
                <div>
                  <p className="font-medium text-success">Ready for Queue Assignment</p>
                  <p className="text-sm text-muted-foreground">
                    Patient will be added to the department queue based on ESI level and available resources.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Navigation Buttons */}
      <div className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={handlePrev}
          disabled={currentStep === 1}
        >
          <ChevronLeft className="mr-2 h-4 w-4" />
          Previous
        </Button>
        {currentStep < steps.length ? (
          <Button onClick={handleNext}>
            Next
            <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        ) : (
          <Button className="bg-success hover:bg-success/90">
            <CheckCircle className="mr-2 h-4 w-4" />
            Complete Check-In
          </Button>
        )}
      </div>
    </div>
  )
}
