'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Activity,
  Clock,
  Users,
  AlertTriangle,
  CheckCircle,
  Play,
  SkipForward,
  Timer,
  TrendingDown,
  Building2,
  RefreshCw
} from 'lucide-react'
import { mockQueue, mockDepartments } from '@/lib/mock-data'

export default function QueuePage() {
  const [selectedDepartment, setSelectedDepartment] = useState('all')
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const filteredQueue = selectedDepartment === 'all' 
    ? mockQueue 
    : mockQueue.filter(q => q.department === selectedDepartment)

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'emergency': return 'bg-destructive text-destructive-foreground'
      case 'urgent': return 'bg-warning text-warning-foreground'
      default: return 'bg-secondary text-secondary-foreground'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in-progress': return 'bg-success/10 text-success border-success/30'
      case 'waiting': return 'bg-warning/10 text-warning border-warning/30'
      default: return 'bg-muted text-muted-foreground border-muted'
    }
  }

  const getStressColor = (score: number | undefined) => {
    if (!score) return 'bg-success'
    if (score >= 7) return 'bg-destructive'
    if (score >= 4) return 'bg-warning'
    return 'bg-success'
  }

  const getWaitTimeColor = (checkInTime: string) => {
    // Simulate wait time calculation
    const waitMinutes = Math.floor(Math.random() * 45) + 5
    if (waitMinutes > 30) return { color: 'text-destructive', minutes: waitMinutes }
    if (waitMinutes > 15) return { color: 'text-warning', minutes: waitMinutes }
    return { color: 'text-success', minutes: waitMinutes }
  }

  const queueStats = {
    totalWaiting: filteredQueue.filter(q => q.status === 'waiting').length,
    inProgress: filteredQueue.filter(q => q.status === 'in-progress').length,
    avgWaitTime: 22,
    emergencies: filteredQueue.filter(q => q.priority === 'emergency').length
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Queue Management</h1>
          <p className="text-muted-foreground mt-1">Real-time patient queue with wait time tracking</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Current Time</p>
            <p className="text-lg font-mono font-bold">
              {currentTime.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </p>
          </div>
          <Button variant="outline" size="icon">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-warning/10">
                <Users className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{queueStats.totalWaiting}</p>
                <p className="text-xs text-muted-foreground">Waiting</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <Play className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{queueStats.inProgress}</p>
                <p className="text-xs text-muted-foreground">In Progress</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Timer className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{queueStats.avgWaitTime} min</p>
                <p className="text-xs text-muted-foreground">Avg. Wait</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-destructive/10">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">{queueStats.emergencies}</p>
                <p className="text-xs text-muted-foreground">Emergencies</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Department Filter & Quick Actions */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              Departments
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger>
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {mockDepartments.map(dept => (
                  <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="space-y-2">
              {mockDepartments.slice(0, 5).map(dept => (
                <div 
                  key={dept.id} 
                  className={`p-3 rounded-lg cursor-pointer transition-all ${
                    selectedDepartment === dept.name ? 'bg-primary/10 border-2 border-primary' : 'bg-muted/30 hover:bg-muted/50 border-2 border-transparent'
                  }`}
                  onClick={() => setSelectedDepartment(dept.name)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm">{dept.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {dept.waitingPatients} waiting
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    ~{dept.averageWaitTime} min avg wait
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Main Queue */}
        <Card className="border-0 shadow-sm lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                Live Queue
                <Badge className="bg-success/10 text-success border-0 ml-2">
                  <span className="h-2 w-2 rounded-full bg-success animate-pulse mr-1.5" />
                  Live
                </Badge>
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                {filteredQueue.length} patients
              </p>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              {filteredQueue.map((entry, index) => {
                const waitInfo = getWaitTimeColor(entry.checkInTime)
                return (
                  <div
                    key={entry.id}
                    className={`p-4 rounded-xl border transition-all hover:shadow-sm ${
                      entry.status === 'in-progress' ? 'bg-success/5 border-success/30' :
                      entry.priority === 'emergency' ? 'bg-destructive/5 border-destructive/30' :
                      entry.priority === 'urgent' ? 'bg-warning/5 border-warning/30' :
                      'bg-card border-border'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      {/* Queue Position */}
                      <div className={`flex items-center justify-center w-10 h-10 rounded-full font-bold text-lg ${
                        entry.status === 'in-progress' ? 'bg-success text-success-foreground' :
                        entry.priority === 'emergency' ? 'bg-destructive text-destructive-foreground' :
                        'bg-primary/10 text-primary'
                      }`}>
                        {entry.status === 'in-progress' ? <Play className="h-5 w-5" /> : entry.position}
                      </div>

                      {/* Patient Info */}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Avatar className="h-8 w-8 border-2 border-background">
                            <AvatarFallback className="bg-secondary text-secondary-foreground text-xs">
                              {entry.patientName.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-semibold text-sm">{entry.patientName}</p>
                            <p className="text-xs text-muted-foreground">{entry.patientId}</p>
                          </div>
                          <Badge className={`text-[10px] ml-2 ${getPriorityColor(entry.priority)}`}>
                            {entry.priority}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Building2 className="h-3 w-3" />
                            {entry.department}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            Check-in: {entry.checkInTime}
                          </span>
                        </div>
                      </div>

                      {/* Wait Time & Status */}
                      <div className="text-right space-y-2">
                        <div>
                          <p className="text-xs text-muted-foreground">Est. Time</p>
                          <p className="font-mono font-semibold">{entry.estimatedTime}</p>
                        </div>
                        <Badge variant="outline" className={getStatusColor(entry.status)}>
                          {entry.status === 'in-progress' && <Play className="h-3 w-3 mr-1" />}
                          {entry.status}
                        </Badge>
                      </div>

                      {/* Wait Timer */}
                      <div className="text-center">
                        <div className={`text-2xl font-bold font-mono ${waitInfo.color}`}>
                          {waitInfo.minutes}
                        </div>
                        <p className="text-[10px] text-muted-foreground">min wait</p>
                        <Progress 
                          value={Math.min((waitInfo.minutes / 45) * 100, 100)} 
                          className={`h-1.5 mt-1 w-16 ${getStressColor(entry.stressIndex)}`}
                        />
                      </div>

                      {/* Stress Index */}
                      {entry.stressIndex !== undefined && (
                        <div className={`p-2 rounded-lg ${
                          entry.stressIndex >= 7 ? 'bg-destructive/10' :
                          entry.stressIndex >= 4 ? 'bg-warning/10' :
                          'bg-success/10'
                        }`}>
                          <p className="text-[10px] text-muted-foreground text-center">ESI</p>
                          <p className={`text-lg font-bold text-center ${
                            entry.stressIndex >= 7 ? 'text-destructive' :
                            entry.stressIndex >= 4 ? 'text-warning' :
                            'text-success'
                          }`}>
                            {entry.stressIndex}
                          </p>
                        </div>
                      )}

                      {/* Actions */}
                      {entry.status === 'waiting' && (
                        <Button size="sm" variant="outline" className="gap-1">
                          <SkipForward className="h-3 w-3" />
                          Call
                        </Button>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Wait Time Legend */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-6">
              <p className="text-sm font-medium">Wait Time Indicators:</p>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-success" />
                <span className="text-sm text-muted-foreground">Normal (0-15 min)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-warning" />
                <span className="text-sm text-muted-foreground">Delayed (15-30 min)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-destructive" />
                <span className="text-sm text-muted-foreground">Critical (30+ min)</span>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <TrendingDown className="h-4 w-4 text-success" />
              <span>30% reduction in wait times this week</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
