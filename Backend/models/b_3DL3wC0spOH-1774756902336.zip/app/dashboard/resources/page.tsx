'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  BarChart3,
  Building2,
  Bed,
  Activity,
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  Wrench,
  XCircle,
  TrendingUp,
  Zap,
  Server
} from 'lucide-react'
import { mockResources, mockDepartments } from '@/lib/mock-data'
import { useState } from 'react'

const resourceStats = {
  total: mockResources.length,
  available: mockResources.filter(r => r.status === 'available').length,
  inUse: mockResources.filter(r => r.status === 'in-use').length,
  maintenance: mockResources.filter(r => r.status === 'maintenance').length,
  avgUtilization: Math.round(mockResources.filter(r => r.status !== 'maintenance').reduce((acc, r) => acc + r.utilization, 0) / mockResources.filter(r => r.status !== 'maintenance').length)
}

export default function ResourcesPage() {
  const [filterType, setFilterType] = useState('all')
  const [filterDepartment, setFilterDepartment] = useState('all')

  const filteredResources = mockResources.filter(r => {
    const matchesType = filterType === 'all' || r.type === filterType
    const matchesDept = filterDepartment === 'all' || r.department === filterDepartment
    return matchesType && matchesDept
  })

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'available': return <CheckCircle className="h-4 w-4 text-success" />
      case 'in-use': return <Activity className="h-4 w-4 text-warning" />
      case 'maintenance': return <Wrench className="h-4 w-4 text-muted-foreground" />
      default: return <XCircle className="h-4 w-4 text-destructive" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'available': return <Badge className="bg-success/10 text-success border-0">Available</Badge>
      case 'in-use': return <Badge className="bg-warning/10 text-warning border-0">In Use</Badge>
      case 'maintenance': return <Badge className="bg-muted text-muted-foreground border-0">Maintenance</Badge>
      default: return <Badge className="bg-destructive/10 text-destructive border-0">Out of Order</Badge>
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'room': return <Building2 className="h-5 w-5" />
      case 'equipment': return <Server className="h-5 w-5" />
      case 'bed': return <Bed className="h-5 w-5" />
      case 'staff': return <Activity className="h-5 w-5" />
      default: return <Settings className="h-5 w-5" />
    }
  }

  const getUtilizationColor = (utilization: number) => {
    if (utilization >= 90) return 'bg-destructive'
    if (utilization >= 70) return 'bg-warning'
    return 'bg-success'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Resource Monitor</h1>
          <p className="text-muted-foreground mt-1">Track rooms, equipment, beds, and staff utilization</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Settings className="h-4 w-4" />
          Manage Resources
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <BarChart3 className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{resourceStats.total}</p>
                <p className="text-xs text-muted-foreground">Total Resources</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <CheckCircle className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{resourceStats.available}</p>
                <p className="text-xs text-muted-foreground">Available</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-warning/10">
                <Activity className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{resourceStats.inUse}</p>
                <p className="text-xs text-muted-foreground">In Use</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-muted">
                <Wrench className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold">{resourceStats.maintenance}</p>
                <p className="text-xs text-muted-foreground">Maintenance</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/10">
                <TrendingUp className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{resourceStats.avgUtilization}%</p>
                <p className="text-xs text-muted-foreground">Avg. Utilization</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Utilization Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* By Type */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Utilization by Type</CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            {['room', 'equipment', 'bed'].map(type => {
              const typeResources = mockResources.filter(r => r.type === type)
              const avgUtil = typeResources.length > 0 
                ? Math.round(typeResources.reduce((acc, r) => acc + r.utilization, 0) / typeResources.length)
                : 0
              const inUse = typeResources.filter(r => r.status === 'in-use').length
              
              return (
                <div key={type} className="p-4 rounded-xl bg-muted/30">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-primary/10">
                        {getTypeIcon(type)}
                      </div>
                      <div>
                        <p className="font-semibold capitalize">{type}s</p>
                        <p className="text-xs text-muted-foreground">{typeResources.length} total</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">{avgUtil}%</p>
                      <p className="text-xs text-muted-foreground">{inUse} in use</p>
                    </div>
                  </div>
                  <Progress value={avgUtil} className={`h-2 ${getUtilizationColor(avgUtil)}`} />
                </div>
              )
            })}
          </CardContent>
        </Card>

        {/* By Department */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Utilization by Department</CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            {mockDepartments.slice(0, 4).map(dept => {
              const deptResources = mockResources.filter(r => r.department === dept.name)
              const avgUtil = deptResources.length > 0
                ? Math.round(deptResources.reduce((acc, r) => acc + r.utilization, 0) / deptResources.length)
                : Math.round((dept.occupiedBeds / dept.totalBeds) * 100)
              
              return (
                <div key={dept.id} className="p-4 rounded-xl bg-muted/30">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-accent/10">
                        <Building2 className="h-5 w-5 text-accent" />
                      </div>
                      <div>
                        <p className="font-semibold">{dept.name}</p>
                        <p className="text-xs text-muted-foreground">{dept.doctors} doctors, {dept.nurses} nurses</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">{avgUtil}%</p>
                      <p className="text-xs text-muted-foreground">capacity</p>
                    </div>
                  </div>
                  <Progress value={avgUtil} className={`h-2 ${getUtilizationColor(avgUtil)}`} />
                </div>
              )
            })}
          </CardContent>
        </Card>
      </div>

      {/* Resource List */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <CardTitle className="text-lg">All Resources</CardTitle>
            <div className="flex items-center gap-2">
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="room">Rooms</SelectItem>
                  <SelectItem value="equipment">Equipment</SelectItem>
                  <SelectItem value="bed">Beds</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Department" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {mockDepartments.map(dept => (
                    <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredResources.map((resource) => (
              <div key={resource.id} className={`p-4 rounded-xl border transition-all hover:shadow-sm ${
                resource.status === 'in-use' ? 'border-warning/30 bg-warning/5' :
                resource.status === 'maintenance' ? 'border-muted bg-muted/30' :
                'border-border bg-card'
              }`}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${
                      resource.status === 'available' ? 'bg-success/10' :
                      resource.status === 'in-use' ? 'bg-warning/10' :
                      'bg-muted'
                    }`}>
                      {getTypeIcon(resource.type)}
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{resource.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{resource.type}</p>
                    </div>
                  </div>
                  {getStatusBadge(resource.status)}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Building2 className="h-3 w-3" />
                      Department
                    </span>
                    <span className="font-medium">{resource.department}</span>
                  </div>
                  
                  {resource.status !== 'maintenance' && (
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground flex items-center gap-1">
                          <Zap className="h-3 w-3" />
                          Utilization
                        </span>
                        <span className="font-medium">{resource.utilization}%</span>
                      </div>
                      <Progress 
                        value={resource.utilization} 
                        className={`h-1.5 ${getUtilizationColor(resource.utilization)}`}
                      />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Bottleneck Alerts */}
      <Card className="border-0 shadow-sm border-l-4 border-l-warning">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            Resource Bottlenecks Detected
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-warning/5">
              <div className="flex items-center gap-3">
                <Bed className="h-5 w-5 text-warning" />
                <div>
                  <p className="font-medium">ICU Beds - Emergency</p>
                  <p className="text-sm text-muted-foreground">100% utilization, 3 patients waiting</p>
                </div>
              </div>
              <Button size="sm" variant="outline" className="text-warning border-warning/50">
                Take Action
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-warning/5">
              <div className="flex items-center gap-3">
                <Server className="h-5 w-5 text-warning" />
                <div>
                  <p className="font-medium">MRI Scanner - Neurology</p>
                  <p className="text-sm text-muted-foreground">Under maintenance, 5 scans pending</p>
                </div>
              </div>
              <Button size="sm" variant="outline" className="text-warning border-warning/50">
                View Schedule
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
