"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { 
  Bell, 
  AlertTriangle, 
  AlertCircle, 
  Info, 
  CheckCircle,
  Clock,
  Users,
  Activity,
  Heart,
  Thermometer,
  Zap,
  Settings,
  X,
  MoreVertical,
  Filter
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

type AlertSeverity = "critical" | "warning" | "info" | "success"

interface Alert {
  id: string
  title: string
  message: string
  severity: AlertSeverity
  category: string
  timestamp: string
  read: boolean
  patient?: string
  room?: string
}

const alerts: Alert[] = [
  {
    id: "1",
    title: "Critical Vitals Alert",
    message: "Patient in Room 205 showing critical blood pressure readings. Immediate attention required.",
    severity: "critical",
    category: "vitals",
    timestamp: "2 minutes ago",
    read: false,
    patient: "John Smith",
    room: "205"
  },
  {
    id: "2",
    title: "Bed Capacity Warning",
    message: "Emergency department bed occupancy has reached 90%. Consider activating surge protocol.",
    severity: "warning",
    category: "capacity",
    timestamp: "15 minutes ago",
    read: false
  },
  {
    id: "3",
    title: "Lab Results Ready",
    message: "Lab results for patient Maria Garcia are now available for review.",
    severity: "info",
    category: "lab",
    timestamp: "32 minutes ago",
    read: false,
    patient: "Maria Garcia",
    room: "312"
  },
  {
    id: "4",
    title: "Staff Shift Change",
    message: "Reminder: Shift change in 30 minutes. Please complete patient handoffs.",
    severity: "info",
    category: "staff",
    timestamp: "45 minutes ago",
    read: true
  },
  {
    id: "5",
    title: "ESI 1 Patient Incoming",
    message: "Trauma patient arriving via EMS in approximately 5 minutes. Prepare trauma bay.",
    severity: "critical",
    category: "incoming",
    timestamp: "1 hour ago",
    read: true
  },
  {
    id: "6",
    title: "Equipment Maintenance",
    message: "CT Scanner 2 scheduled maintenance completed successfully.",
    severity: "success",
    category: "equipment",
    timestamp: "2 hours ago",
    read: true
  },
  {
    id: "7",
    title: "Queue Wait Time Alert",
    message: "Average wait time in waiting room exceeds 45 minutes. Consider triage review.",
    severity: "warning",
    category: "queue",
    timestamp: "2 hours ago",
    read: true
  },
  {
    id: "8",
    title: "Medication Reminder",
    message: "Scheduled medication administration for Room 118 in 10 minutes.",
    severity: "info",
    category: "medication",
    timestamp: "3 hours ago",
    read: true
  },
]

const alertRules = [
  { id: "1", name: "Critical Vitals", description: "Alert when patient vitals reach critical thresholds", enabled: true, category: "vitals" },
  { id: "2", name: "Bed Capacity", description: "Alert when bed occupancy exceeds 85%", enabled: true, category: "capacity" },
  { id: "3", name: "Wait Time", description: "Alert when average wait time exceeds 30 minutes", enabled: true, category: "queue" },
  { id: "4", name: "Lab Results", description: "Notify when lab results are available", enabled: true, category: "lab" },
  { id: "5", name: "Shift Changes", description: "Reminder 30 minutes before shift change", enabled: true, category: "staff" },
  { id: "6", name: "ESI 1/2 Arrivals", description: "Alert for incoming high-acuity patients", enabled: true, category: "incoming" },
  { id: "7", name: "Equipment Status", description: "Alert for equipment maintenance updates", enabled: false, category: "equipment" },
  { id: "8", name: "Medication Reminders", description: "Scheduled medication administration alerts", enabled: true, category: "medication" },
]

export default function AlertsPage() {
  const [alertList, setAlertList] = useState(alerts)
  const [rules, setRules] = useState(alertRules)

  const unreadCount = alertList.filter(a => !a.read).length
  const criticalCount = alertList.filter(a => a.severity === "critical" && !a.read).length

  const getSeverityIcon = (severity: AlertSeverity) => {
    switch (severity) {
      case "critical": return <AlertTriangle className="h-5 w-5" />
      case "warning": return <AlertCircle className="h-5 w-5" />
      case "info": return <Info className="h-5 w-5" />
      case "success": return <CheckCircle className="h-5 w-5" />
    }
  }

  const getSeverityStyles = (severity: AlertSeverity) => {
    switch (severity) {
      case "critical": return "border-destructive/50 bg-destructive/5"
      case "warning": return "border-warning/50 bg-warning/5"
      case "info": return "border-info/50 bg-info/5"
      case "success": return "border-success/50 bg-success/5"
    }
  }

  const getSeverityTextColor = (severity: AlertSeverity) => {
    switch (severity) {
      case "critical": return "text-destructive"
      case "warning": return "text-warning"
      case "info": return "text-info"
      case "success": return "text-success"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "vitals": return <Heart className="h-4 w-4" />
      case "capacity": return <Users className="h-4 w-4" />
      case "queue": return <Clock className="h-4 w-4" />
      case "lab": return <Activity className="h-4 w-4" />
      case "staff": return <Users className="h-4 w-4" />
      case "incoming": return <Zap className="h-4 w-4" />
      case "equipment": return <Settings className="h-4 w-4" />
      case "medication": return <Thermometer className="h-4 w-4" />
      default: return <Bell className="h-4 w-4" />
    }
  }

  const markAsRead = (id: string) => {
    setAlertList(prev => prev.map(alert => 
      alert.id === id ? { ...alert, read: true } : alert
    ))
  }

  const dismissAlert = (id: string) => {
    setAlertList(prev => prev.filter(alert => alert.id !== id))
  }

  const markAllAsRead = () => {
    setAlertList(prev => prev.map(alert => ({ ...alert, read: true })))
  }

  const toggleRule = (id: string) => {
    setRules(prev => prev.map(rule =>
      rule.id === id ? { ...rule, enabled: !rule.enabled } : rule
    ))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Alerts & Notifications</h1>
          <p className="text-muted-foreground">
            Manage system alerts and notification preferences
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <Button variant="outline" onClick={markAllAsRead}>
            Mark All Read
          </Button>
        </div>
      </div>

      {/* Alert Summary */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unread Alerts</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{unreadCount}</div>
            <p className="text-xs text-muted-foreground">Require attention</p>
          </CardContent>
        </Card>
        <Card className="border-destructive/30">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{criticalCount}</div>
            <p className="text-xs text-muted-foreground">Immediate action needed</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{alertList.length}</div>
            <p className="text-xs text-muted-foreground">Total alerts today</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Rules</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{rules.filter(r => r.enabled).length}</div>
            <p className="text-xs text-muted-foreground">of {rules.length} rules</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all" className="gap-2">
            All
            {unreadCount > 0 && (
              <Badge variant="secondary" className="ml-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                {unreadCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="critical" className="gap-2">
            Critical
            {criticalCount > 0 && (
              <Badge variant="destructive" className="ml-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                {criticalCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="unread">Unread</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          {alertList.map((alert) => (
            <Card 
              key={alert.id} 
              className={`${getSeverityStyles(alert.severity)} ${!alert.read ? "ring-2 ring-offset-2" : ""}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className={`mt-0.5 ${getSeverityTextColor(alert.severity)}`}>
                    {getSeverityIcon(alert.severity)}
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="font-semibold">{alert.title}</h4>
                        <p className="text-sm text-muted-foreground">{alert.message}</p>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {!alert.read && (
                            <DropdownMenuItem onClick={() => markAsRead(alert.id)}>
                              Mark as Read
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem onClick={() => dismissAlert(alert.id)}>
                            Dismiss
                          </DropdownMenuItem>
                          {alert.patient && (
                            <DropdownMenuItem>View Patient</DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <div className="flex items-center gap-4 pt-2">
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        {getCategoryIcon(alert.category)}
                        <span className="capitalize">{alert.category}</span>
                      </div>
                      {alert.patient && (
                        <Badge variant="outline" className="text-xs">
                          {alert.patient}
                        </Badge>
                      )}
                      {alert.room && (
                        <Badge variant="secondary" className="text-xs">
                          Room {alert.room}
                        </Badge>
                      )}
                      <span className="text-xs text-muted-foreground ml-auto">
                        {alert.timestamp}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="critical" className="space-y-4">
          {alertList
            .filter(a => a.severity === "critical")
            .map((alert) => (
              <Card 
                key={alert.id} 
                className={`${getSeverityStyles(alert.severity)} ${!alert.read ? "ring-2 ring-offset-2" : ""}`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={`mt-0.5 ${getSeverityTextColor(alert.severity)}`}>
                      {getSeverityIcon(alert.severity)}
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="font-semibold">{alert.title}</h4>
                          <p className="text-sm text-muted-foreground">{alert.message}</p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 shrink-0"
                          onClick={() => dismissAlert(alert.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="flex items-center gap-4 pt-2">
                        {alert.patient && (
                          <Badge variant="outline" className="text-xs">
                            {alert.patient}
                          </Badge>
                        )}
                        {alert.room && (
                          <Badge variant="secondary" className="text-xs">
                            Room {alert.room}
                          </Badge>
                        )}
                        <span className="text-xs text-muted-foreground ml-auto">
                          {alert.timestamp}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
        </TabsContent>

        <TabsContent value="unread" className="space-y-4">
          {alertList
            .filter(a => !a.read)
            .map((alert) => (
              <Card 
                key={alert.id} 
                className={`${getSeverityStyles(alert.severity)} ring-2 ring-offset-2`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={`mt-0.5 ${getSeverityTextColor(alert.severity)}`}>
                      {getSeverityIcon(alert.severity)}
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="font-semibold">{alert.title}</h4>
                          <p className="text-sm text-muted-foreground">{alert.message}</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => markAsRead(alert.id)}
                        >
                          Mark Read
                        </Button>
                      </div>
                      <div className="flex items-center gap-4 pt-2">
                        <span className="text-xs text-muted-foreground ml-auto">
                          {alert.timestamp}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          {alertList.filter(a => !a.read).length === 0 && (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <CheckCircle className="h-12 w-12 text-success mb-4" />
                <h3 className="text-lg font-semibold">All Caught Up!</h3>
                <p className="text-sm text-muted-foreground">No unread alerts at this time.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Alert Rules</CardTitle>
              <CardDescription>Configure which alerts you want to receive</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {rules.map((rule) => (
                <div key={rule.id} className="flex items-center justify-between py-3 border-b last:border-0">
                  <div className="flex items-center gap-4">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                      rule.enabled ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                    }`}>
                      {getCategoryIcon(rule.category)}
                    </div>
                    <div>
                      <p className="font-medium">{rule.name}</p>
                      <p className="text-sm text-muted-foreground">{rule.description}</p>
                    </div>
                  </div>
                  <Switch 
                    checked={rule.enabled}
                    onCheckedChange={() => toggleRule(rule.id)}
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
